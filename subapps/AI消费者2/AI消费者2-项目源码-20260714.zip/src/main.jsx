import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Activity,
  BookOpenCheck,
  BadgeDollarSign,
  Check,
  ChevronRight,
  CircleDollarSign,
  ClipboardList,
  Clock3,
  Database,
  Download,
  Filter,
  Gauge,
  History,
  Grid2X2,
  Layers3,
  LineChart,
  MessagesSquare,
  Paperclip,
  Pencil,
  Play,
  Plus,
  RefreshCw,
  Search,
  Send,
  Settings,
  SlidersHorizontal,
  Star,
  Target,
  Trash2,
  TrendingUp,
  TriangleAlert,
  Upload,
  UserRound,
  UsersRound,
  X
} from 'lucide-react';
import './styles.css';
import aiConsumerLogo from './assets/ai-consumer-logo.png';
import { buildConsumerConditionCoverage, buildConsumerSamplePreview, buildConsumerUsage, buildUserDataPresentation, groupUserTagsByCategory, paginate, summarizeTags } from './list-utils.mjs';
import { Bar, BarChart, CartesianGrid, Cell, ComposedChart, LabelList, Legend, Line, LineChart as RechartsLineChart, Pie, PieChart, PolarAngleAxis, PolarGrid, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

const analysisDimensionOptions = ['年龄段', '性别', '城市级别', '家庭阶段', '购车预算', '新能源经验', '品牌偏好'];

const scenarios = [
  {
    id: 'design',
    name: '造型方向验证',
    stage: '产品设计阶段',
    icon: Layers3,
    summary: '将造型文字描述分发给 AI 消费者，验证外观设计语言的接受度。',
    defaultQuestion: '这套造型语言是否符合你的审美？哪些细节会影响购买兴趣？',
    inputTitle: '设计语言描述',
    inputValue:
      '紧凑型纯电 SUV，封闭式前脸，贯穿式 LED 灯带，悬浮式车顶，隐藏式门把手，尾部采用贯穿式尾灯与运动扩散器，整体偏年轻运动科技风格。',
    metrics: [
      { label: '整体造型', value: 7.8, delta: '+0.6' },
      { label: '前脸设计', value: 8.2, delta: '+0.9' },
      { label: '侧面比例', value: 7.5, delta: '+0.3' },
      { label: '尾部设计', value: 7.0, delta: '-0.1' }
    ],
    primary: '整体好感度 76%',
    recommendation: '保留贯穿式灯带与运动前脸，降低车身视觉高度，尾部需要增加辨识度。'
  },
  {
    id: 'config',
    name: '配置偏好验证',
    stage: '产品定义阶段',
    icon: SlidersHorizontal,
    summary: '比较不同续航、智驾、座舱、舒适性配置组合的人群偏好。',
    defaultQuestion: '你更倾向哪个配置方案？哪些配置最不实用？',
    inputTitle: '配置方案',
    inputValue:
      '方案A：500km 续航，L2 智驾，基础音响；方案B：600km 续航，L2+智驾，品牌音响，前排座椅加热；方案C：600km 续航，后排娱乐屏，座椅通风按摩。',
    metrics: [
      { label: '方案A', value: 22, delta: '预算敏感' },
      { label: '方案B', value: 52, delta: '主流首选' },
      { label: '方案C', value: 26, delta: '高配追求' }
    ],
    primary: '方案B 偏好度 52%',
    recommendation: '中配方案覆盖最广；家庭用户可对后排娱乐屏做选装包，而不是推为标配。'
  },
  {
    id: 'purchase',
    name: '购买意愿与市占预测',
    stage: '新车上市阶段',
    icon: LineChart,
    summary: '模拟目标人群对车型卖点、版本与价格区间的购买决策。',
    defaultQuestion: '在预算范围内你是否会考虑本车型？最影响决策的因素是什么？',
    inputTitle: '上市产品信息',
    inputValue:
      '紧凑型纯电 SUV，预售价 18-22 万，600km CLTC，8295 智能座舱，L2+智驾，百公里加速 6.8 秒，基础/中配/高配三个版本。',
    metrics: [
      { label: '高意愿', value: 28, delta: '+8pp' },
      { label: '中意愿', value: 34, delta: '+5pp' },
      { label: '低意愿', value: 38, delta: '-13pp' },
      { label: '中配偏好', value: 52, delta: '最优' }
    ],
    primary: '整体购买意愿 62%',
    recommendation: '中配版是上市主推锚点；智能座舱与续航为核心传播卖点。'
  },
  {
    id: 'price',
    name: '价格敏感度与定价优化',
    stage: '新车上市阶段',
    icon: CircleDollarSign,
    summary: '对多价格点进行分组测试，输出购买概率曲线与建议定价区间。',
    defaultQuestion: '不同价格点下，你的购买概率如何变化？',
    inputTitle: '价格测试点',
    inputValue: '中配版：17 万、18.5 万、20 万、21.5 万、23 万，分 5 组，每组 500 名 AI 消费者。',
    metrics: [
      { label: '17万', value: 78, delta: '极具吸引力' },
      { label: '18.5万', value: 65, delta: '较高意愿' },
      { label: '20万', value: 52, delta: '临界点' },
      { label: '21.5万', value: 35, delta: '明显下滑' }
    ],
    primary: '建议定价 19-20.5 万',
    recommendation: '20.5 万以上购买意愿快速下降；低于 19 万能拉升意愿但压缩利润。'
  }
];

const tagGroups = [
  {
    group: '基础属性',
    tags: [
      { id: 'age-25-35', name: '25-35岁', size: 687540 },
      { id: 'gen-95', name: '95后/00后', size: 412900 },
      { id: 'social-90', name: '90后社会年龄', size: 536200 },
      { id: 'female-user', name: '女性用户', size: 384600 }
    ]
  },
  {
    group: '地域属性',
    tags: [
      { id: 'city-tier1', name: '一线/新一线城市', size: 458760 },
      { id: 'city-tier3', name: '三线及以下潜客', size: 522300 },
      { id: 'limited-city', name: '限购城市用户', size: 219800 },
      { id: 'province-east', name: '华东核心城市', size: 366100 }
    ]
  },
  {
    group: '运营商行为',
    tags: [
      { id: 'data-heavy', name: '高流量使用', size: 482900 },
      { id: 'fee-high', name: '高话费消费', size: 318400 },
      { id: 'long-tenure', name: '长网龄用户', size: 729500 },
      { id: 'roaming-active', name: '省际漫游活跃', size: 207300 }
    ]
  },
  {
    group: '购车意向',
    tags: [
      { id: 'bev', name: '新能源车偏好', size: 512300 },
      { id: 'budget-15-25', name: '预算15-25万', size: 598120 },
      { id: 'suv', name: 'SUV偏好人群', size: 428550 },
      { id: 'first-car', name: '首次购车用户', size: 338900 },
      { id: 'brand-mainstream', name: '自主品牌偏好', size: 291400 }
    ]
  },
  {
    group: '车主相关',
    tags: [
      { id: 'owner-ev', name: '电动车主/潜客', size: 238700 },
      { id: 'owner-none', name: '无车潜客', size: 487200 },
      { id: 'owner-upgrade', name: '增换购车主', size: 273800 },
      { id: 'driving-school', name: '驾考服务用户', size: 152600 }
    ]
  },
  {
    group: '家庭状态',
    tags: [
      { id: 'family-child', name: '家庭首购换购', size: 312100 },
      { id: 'married', name: '已婚家庭', size: 468200 },
      { id: 'multi-child', name: '多孩家庭', size: 146500 },
      { id: 'single-commute', name: '单身通勤族', size: 389700 }
    ]
  },
  {
    group: '消费能力',
    tags: [
      { id: 'middle-high', name: '中高消费能力', size: 298760 },
      { id: 'high-consume', name: '高消费能力用户', size: 187600 },
      { id: 'mid-consume', name: '中等消费能力', size: 642300 },
      { id: 'price-sensitive', name: '价格敏感型用户', size: 354900 }
    ]
  },
  {
    group: '兴趣爱好',
    tags: [
      { id: 'tech-savvy', name: '科技尝鲜者', size: 185900 },
      { id: 'movie-ticket', name: '电影票务高频', size: 251300 },
      { id: 'outdoor-fishing', name: '户外钓鱼兴趣', size: 134700 },
      { id: 'beauty-fashion', name: '美容打扮兴趣', size: 201600 }
    ]
  },
  {
    group: 'APP偏好',
    tags: [
      { id: 'app-auto', name: '汽车垂媒高活跃', size: 167300 },
      { id: 'app-shopping', name: '购物APP高活跃', size: 473600 },
      { id: 'app-shortvideo', name: '短视频高活跃', size: 582900 },
      { id: 'app-navigation', name: '地图出行高活跃', size: 406700 }
    ]
  },
  {
    group: '生活偏好',
    tags: [
      { id: 'commute', name: '通勤出行高频', size: 386420 },
      { id: 'travel-active', name: '旅游出行偏好', size: 226800 },
      { id: 'office-worker', name: '办公工具高频', size: 331500 },
      { id: 'sports-life', name: '体育生活偏好', size: 174200 }
    ]
  }
];

const taxonomyRows = [
  ['个人属性', '性别', '男、女'],
  ['个人属性', '年龄', '15岁以下、15岁、16岁、17岁、18岁、19岁、20岁、21岁、22岁、23岁、24岁、25岁、26岁、27岁、28岁、29岁、30岁、31岁、32岁、33岁、34岁、35岁、36岁、37岁、38岁、39岁、40岁、41岁、42岁、43岁、44岁、45岁、46岁、47岁、48岁、49岁、50岁、51岁、52岁、53岁、54岁、55岁、56岁、57岁、58岁、59岁、60岁、61岁、62岁、63岁、64岁、65岁、66岁、67岁、68岁、69岁、70岁以上'],
  ['个人属性', '教育水平', '高中及以下、大专、本科、硕士及以上'],
  ['个人属性', '工作单位性质', '机关事业单位、国有企业、私营企业、外资企业、个体户、农民、自由职业者、无业、其他'],
  ['个人属性', '行业类型', '学校/科研机构、退休人员、医疗机构、医疗/护理/制药、商业/零售/服务业、个体经营、政府机关/事业单位、计算机/个人独资企业、互联网/通信、其他'],
  ['个人属性', '职业类型', '机关/事业单位工作人员、企业职员、个体经营者、学生、退休人员、其他'],
  ['个人属性', '岗位级别', '普通员工、基层管理岗、中层管理岗、高层管理岗、无固定岗位、其他'],
  ['个人属性', '居住城市', '居住城市名称'],
  ['个人属性', '居住区域', '城市、乡镇、农村'],
  ['个人属性', '是否本地人', '是、否'],
  ['个人属性', '价值观', '享乐、刺激、自主、博爱（社会公益/利他）、友善（关爱家庭/朋友）、传统、安全、权力、成就'],
  ['家庭属性', '婚姻状况', '已婚、单身、恋爱中'],
  ['家庭属性', '是否有小孩', '是、否'],
  ['家庭属性', '小孩数量', '0、1人、2人、3人以上'],
  ['家庭属性', '1孩年龄', '无、0-2岁、2-6岁、6-12岁、12-18岁、18岁以上'],
  ['家庭属性', '2孩年龄', '无、0-2岁、2-6岁、6-12岁、12-18岁、18岁以上'],
  ['家庭属性', '3孩年龄', '无、0-2岁、2-6岁、6-12岁、12-18岁、18岁以上'],
  ['家庭属性', '是否与老人同住', '是、否'],
  ['家庭属性', '同住老人数量', '0、1人、2人、3人、4人、4人以上'],
  ['家庭属性', '同住人数', '1人、2人、3人、4人、5人、6人、7人及以上'],
  ['家庭属性', '老人是否同城', '是、否'],
  ['经济属性', '个人年收入', '5万以下、5-10万、10-20万、20-30万、30-50万、50万以上'],
  ['经济属性', '家庭年收入', '5万以下、5-10万、10-20万、20-30万、30-50万、50万以上'],
  ['经济属性', '家庭购买力', '10万以下、10-20万、20-30万、30-50万、50-100万、100-300万、300-500万、500万以上'],
  ['经济属性', '住房状况', '自有住房无贷款、自有住房有贷款、租房、其他'],
  ['经济属性', '拥有房产数量', '0、1套、2套、3套及以上'],
  ['经济属性', '消费重心', '个人、子女、老人、家庭'],
  ['偏好属性', '消费观', '冲动消费、谨慎消费、个性消费、从众消费、尝鲜消费、保守消费、品质消费、性价比、潮流消费、实用消费、颜值消费、品牌信仰消费、高价导向消费、折扣优惠驱动消费、情怀消费、科技引领消费'],
  ['偏好属性', '兴趣爱好', '滑雪、篮球、羽毛球、瑜伽、逛商场、逛街、烹饪、听音乐、动漫二次元、听书、其他'],
  ['偏好属性', '养宠情况', '无宠物、猫、狗、鸟类、鱼类、小型哺乳动物、其他'],
  ['偏好属性', '户外活动频率', '每天1次及以上、每周3-5次、每周1-2次、每月1-2次、很少'],
  ['偏好属性', '线下社交频率', '每天1次及以上、每周3-5次、每周1-2次、每月1-2次、很少'],
  ['偏好属性', '穿搭风格偏好', '休闲舒适风、简约通勤风、运动活力风、潮流个性风、优雅复古风、无固定风格、其他'],
  ['偏好属性', '旅行方式偏好', '不喜欢旅行、自由行、跟团游、与亲友结伴游、定制游'],
  ['出行属性', '日常通勤方式', '步行、自行车、电动自行车、公交、地铁、自驾、网约车、班车'],
  ['出行属性', '日常通勤单程距离', '1公里以内、1-3公里、3-5公里、5-10公里、10-20公里、20公里以上'],
  ['出行属性', '日常通勤用车频次', '0、每周1天、每周2天、每周3天、每周4天、每周5天'],
  ['出行属性', '周末出行目的', '购物消费、休闲娱乐、探亲访友、户外运动、居家、其他'],
  ['出行属性', '周末出行方式', '步行、自行车、电动自行车、公交、地铁、自驾、网约车、班车'],
  ['出行属性', '周末出行单程距离', '1公里以内、1-3公里、3-5公里、5-10公里、10-20公里、20公里以上'],
  ['出行属性', '周末出行用车频次', '0、每月1次、每月2次、每月3次、每月4次'],
  ['出行属性', '周末同行人员类型', '自己、家人、朋友、同事、其他'],
  ['出行属性', '节假日出行时长', '1天以内、1-2天、3-5天、5-7天、7天以上'],
  ['出行属性', '节假日出行交通方式', '火车/高铁/动车、飞机、私家车、旅游大巴、其他'],
  ['出行属性', '跨城出行频次', '每月1次及以上、每季度1-2次、每半年1-2次、每年1-2次、几乎不跨城'],
  ['拥车属性', '家庭目前拥车数量', '0、1辆、2辆、3辆及以上'],
  ['拥车属性', '驾龄', '1-3年、3-5年、5-10年、10-20年、20年以上'],
  ['拥车属性', '年度驾驶里程', '0-1000km、1000-5000km、5000-10000km、10000-50000km、50000km以上'],
  ['拥车属性', '家庭目前第1台车品牌', '汽车品牌名称，如：长安、吉利'],
  ['拥车属性', '家庭目前第1台车车型', '汽车车型名称，如：启源Q07激光雷达版、小米SU7'],
  ['拥车属性', '家庭目前第2台车品牌', '汽车品牌名称，如：长安、吉利'],
  ['拥车属性', '家庭目前第2台车车型', '汽车车型名称，如：启源Q07激光雷达版、小米SU7'],
  ['拥车属性', '双方父母当前拥车数量', '0、1辆、2辆、3辆及以上'],
  ['拥车属性', '双方父母当前第1台车品牌', '汽车品牌名称，如：长安、吉利'],
  ['拥车属性', '双方父母当前第1台车车型', '汽车车型名称，如：启源Q07激光雷达版、小米SU7'],
  ['拥车属性', '双方父母当前第2台车品牌', '汽车品牌名称，如：长安、吉利'],
  ['拥车属性', '双方父母当前第2台车车型', '汽车车型名称，如：启源Q07激光雷达版、小米SU7'],
  ['拥车属性', '孩子当前拥车数量', '0、1辆、2辆、3辆及以上'],
  ['拥车属性', '孩子当前第1台车品牌', '汽车品牌名称，如：长安、吉利'],
  ['拥车属性', '孩子当前第1台车车型', '汽车车型名称，如：启源Q07激光雷达版、小米SU7'],
  ['拥车属性', '孩子当前第2台车品牌', '汽车品牌名称，如：长安、吉利'],
  ['拥车属性', '孩子当前第2台车车型', '汽车车型名称，如：启源Q07激光雷达版、小米SU7'],
  ['拥车属性', '是否有过置换', '是、否'],
  ['拥车属性', '置换前车辆品牌', '汽车品牌名称，如：长安、吉利'],
  ['拥车属性', '置换前车辆车型', '汽车车型名称，如：启源Q07激光雷达版、小米SU7'],
  ['拥车属性', '车辆置换周期预期', '3年内、3-5年、5-8年、8-10年、不考虑置换'],
  ['拥车属性', '未来1-3年购车计划', '无购车计划、计划增购、计划换购、计划首购、不确定'],
  ['最近一次购车情况', '购车情形', '首购、增购、换购'],
  ['最近一次购车情况', '购车动机', '通勤刚需、消费升级、家庭准备、出行降本'],
  ['最近一次购车情况', '购车主要用途', '日常通勤、家庭出行、长途旅游、商务接待、越野/改装、其他'],
  ['最近一次购车情况', '购车品牌', '汽车品牌名称，如：长安、吉利'],
  ['最近一次购车情况', '购车车型', '汽车车型名称，如：启源Q07激光雷达版、小米SU7'],
  ['最近一次购车情况', '购车预算', '5万以下、5-8万、8-10万、10-12万、12-15万、15-18万、18-20万、20-30万、30-50万、50万以上'],
  ['最近一次购车情况', '购车价位', '5万以下、5-8万、8-10万、10-12万、12-15万、15-18万、18-20万、20-30万、30-50万、50万以上'],
  ['最近一次购车情况', '购车时优先考虑因素', '性价比、品牌、安全性能、空间大小、油耗/电耗、配置能量、外观设计、舒适性、其他'],
  ['最近一次购车情况', '汽车信息获取主要渠道', '汽车垂媒、短视频平台、空间APP、线下4S店、官网、朋友/同事推荐、汽车论坛/社群'],
  ['最近一次购车情况', '对比车型', '汽车车型名称，如：启源Q07激光雷达版、小米SU7'],
  ['最近一次购车情况', '促购原因', '性价比、品牌、安全性能、空间大小、油耗/电耗、配置能量、外观设计、舒适性、其他'],
  ['最近一次购车情况', '购买决策人', '个人独立决策、夫妻/伴侣共同决策、家庭集体讨论决策、父母主导决策、子女主导决策、其他']
].map(([category, name, content], index) => ({ id: `TAX-${String(index + 1).padStart(3, '0')}`, category, name, content, values: content.split('、') }));

const taxonomySeed = taxonomyRows.map((row) => ({
  ...row,
  definition: `${row.category}中的${row.name}标签，用于消费者画像圈选与洞察分析。`,
  synonyms: '',
  status: '启用'
}));

const questionTemplates = [
  '整体吸引力、差异化感知、购买意愿、推荐意愿',
  '最吸引点、最担心点、放弃原因、可接受价格',
  '按年龄/城市/预算/家庭状态拆分偏好差异',
  '开放式原声：用自己的话评价这款车'
];

const menuGroups = [
  {
    items: [
      { label: '模拟问答', icon: MessagesSquare, page: 'qa' },
      { label: '消费调研', icon: ClipboardList, page: 'survey' }
    ]
  },
  {
    parent: '数据资产',
    items: [
      { label: '消费者库', icon: UsersRound, page: 'consumers' },
      { label: '调研场景', icon: ClipboardList, page: 'scenarios' },
      { label: '标签体系', icon: Layers3, page: 'tags' },
      { label: '用户数据', icon: Database, page: 'users' }
    ]
  }
];

const quotes = [
  { persona: '科技尝鲜者，32岁，上海', text: '前脸灯带有科技感，但如果侧面显高，会让我担心它不像一台运动 SUV。', sentiment: '正向' },
  { persona: '家庭务实派，35岁，北京', text: '600km 续航和智能座舱是核心，座椅通风我愿意为中高配加钱。', sentiment: '正向' },
  { persona: '价格敏感型，28岁，成都', text: '20 万是心理临界点，超过 21 万我会去看同价位竞品。', sentiment: '风险' }
];

const researchTasks = [
  {
    id: 'T-240718-001',
    name: '2025款 智行 Compact EV SUV · 造型方向验证',
    scenarioId: 'design',
    status: '已完成',
    creator: '张明',
    sample: 1258,
    updatedAt: '今天 11:20',
    consumer: '25-35岁新能源潜客',
    result: '整体好感度 76%'
  },
  {
    id: 'T-240718-002',
    name: '中配版配置组合偏好测试',
    scenarioId: 'config',
    status: '进行中',
    creator: '李倩',
    sample: 1800,
    updatedAt: '今天 10:06',
    consumer: '家庭首购换购人群',
    result: '已回收 68%'
  },
  {
    id: 'T-240717-009',
    name: '上市前购买意愿与市占预测',
    scenarioId: 'purchase',
    status: '已完成',
    creator: '王珂',
    sample: 3200,
    updatedAt: '昨天 18:42',
    consumer: '中高消费新能源潜客',
    result: '整体购买意愿 62%'
  },
  {
    id: 'T-240716-004',
    name: '20万价格点敏感度复测',
    scenarioId: 'price',
    status: '未开始',
    creator: '赵宁',
    sample: 0,
    updatedAt: '昨天 15:30',
    consumer: '待配置',
    result: '未发布'
  },
  {
    id: 'T-240716-003',
    name: '前脸贯穿灯带接受度复核',
    scenarioId: 'design',
    status: '已完成',
    creator: '陈露',
    sample: 1450,
    updatedAt: '07-16 14:12',
    consumer: '科技尝鲜者',
    result: '前脸设计 8.1'
  },
  {
    id: 'T-240715-011',
    name: '后排娱乐屏选装价值评估',
    scenarioId: 'config',
    status: '已完成',
    creator: '周航',
    sample: 2100,
    updatedAt: '07-15 17:36',
    consumer: '有孩家庭用户',
    result: '选装接受 64%'
  },
  {
    id: 'T-240715-006',
    name: '18.5万价格点购买概率测试',
    scenarioId: 'price',
    status: '已完成',
    creator: '赵宁',
    sample: 2500,
    updatedAt: '07-15 12:08',
    consumer: '预算15-25万潜客',
    result: '购买概率 65%'
  },
  {
    id: 'T-240714-014',
    name: '智能座舱卖点吸引力测试',
    scenarioId: 'purchase',
    status: '进行中',
    creator: '王珂',
    sample: 2800,
    updatedAt: '07-14 19:20',
    consumer: '汽车垂媒高活跃',
    result: '已回收 51%'
  },
  {
    id: 'T-240714-008',
    name: '悬浮式车顶审美分层分析',
    scenarioId: 'design',
    status: '已完成',
    creator: '陈露',
    sample: 1360,
    updatedAt: '07-14 10:46',
    consumer: '一线城市年轻用户',
    result: '侧面比例 7.6'
  },
  {
    id: 'T-240713-017',
    name: '基础版配置减配风险评估',
    scenarioId: 'config',
    status: '未开始',
    creator: '李倩',
    sample: 0,
    updatedAt: '07-13 16:24',
    consumer: '首次购车用户',
    result: '未发布'
  },
  {
    id: 'T-240713-012',
    name: '高配版舒适配置溢价接受度',
    scenarioId: 'config',
    status: '已完成',
    creator: '周航',
    sample: 1680,
    updatedAt: '07-13 11:02',
    consumer: '高配追求型用户',
    result: '偏好度 26%'
  },
  {
    id: 'T-240712-020',
    name: '三线城市上市转化预测',
    scenarioId: 'purchase',
    status: '已完成',
    creator: '王珂',
    sample: 2200,
    updatedAt: '07-12 18:15',
    consumer: '三线及以下潜客',
    result: '购买意愿 52%'
  },
  {
    id: 'T-240712-015',
    name: '21.5万价格点流失原因分析',
    scenarioId: 'price',
    status: '已完成',
    creator: '赵宁',
    sample: 2500,
    updatedAt: '07-12 15:48',
    consumer: '价格敏感型用户',
    result: '购买概率 35%'
  },
  {
    id: 'T-240711-018',
    name: '尾部贯穿灯识别度优化测试',
    scenarioId: 'design',
    status: '进行中',
    creator: '陈露',
    sample: 1500,
    updatedAt: '07-11 20:10',
    consumer: 'SUV偏好人群',
    result: '已回收 43%'
  },
  {
    id: 'T-240711-010',
    name: '品牌音响配置吸引力复测',
    scenarioId: 'config',
    status: '已完成',
    creator: '李倩',
    sample: 1600,
    updatedAt: '07-11 13:33',
    consumer: '中高消费能力人群',
    result: '吸引力 58%'
  },
  {
    id: 'T-240710-021',
    name: '首购与增换购购买路径差异',
    scenarioId: 'purchase',
    status: '未开始',
    creator: '孙悦',
    sample: 0,
    updatedAt: '07-10 18:02',
    consumer: '首购/增换购混合人群',
    result: '未发布'
  },
  {
    id: 'T-240710-016',
    name: '17万低价策略销量拉动测试',
    scenarioId: 'price',
    status: '已完成',
    creator: '赵宁',
    sample: 2500,
    updatedAt: '07-10 14:20',
    consumer: '预算边界用户',
    result: '购买概率 78%'
  },
  {
    id: 'T-240709-019',
    name: 'L2+智驾作为主卖点可行性',
    scenarioId: 'purchase',
    status: '已完成',
    creator: '孙悦',
    sample: 2400,
    updatedAt: '07-09 17:42',
    consumer: '科技配置关注者',
    result: '吸引力 71%'
  },
  {
    id: 'T-240709-013',
    name: '隐藏式门把手负面反馈归因',
    scenarioId: 'design',
    status: '已完成',
    creator: '陈露',
    sample: 1180,
    updatedAt: '07-09 12:55',
    consumer: '家庭务实派',
    result: '风险反馈 18%'
  },
  {
    id: 'T-240708-007',
    name: '23万高价上限测试',
    scenarioId: 'price',
    status: '已完成',
    creator: '赵宁',
    sample: 2500,
    updatedAt: '07-08 16:35',
    consumer: '高消费能力用户',
    result: '购买概率 22%'
  }
];

const seededUserDataAssets = [
  { id: 'U-10001', phone: '138****6271', name: '周雨晴', tags: ['25岁', '女', '本科', '城市', '计划首购', '15-18万'], creator: '张明', updatedAt: '今天 11:20', status: '启用', source: '是通科技购车意向标签库' },
  { id: 'U-10002', phone: '186****9035', name: '顾承安', tags: ['已婚', '2人', '20-30万', '自驾', '计划增购'], creator: '李倩', updatedAt: '今天 10:42', status: '启用', source: '历史调研样本库' },
  { id: 'U-10003', phone: '139****5128', name: '林思远', tags: ['科技引领消费', '互联网/通信', '电动自行车', '汽车垂媒'], creator: '王珂', updatedAt: '今天 09:58', status: '启用', source: '富通 VOC 观点库' },
  { id: 'U-10004', phone: '159****7746', name: '陈若岚', tags: ['单身', '租房', '15-18万', '计划首购', '城市'], creator: '赵宁', updatedAt: '昨天 18:22', status: '停用', source: '是通科技基础属性标签库' },
  { id: 'U-10005', phone: '135****8116', name: '黄启明', tags: ['25岁', '尝鲜消费', '短视频平台', '电动自行车'], creator: '陈露', updatedAt: '昨天 16:40', status: '启用', source: '是通科技运营商行为标签' },
  { id: 'U-10006', phone: '188****2390', name: '姚一诺', tags: ['女', '已婚', '2人', '20-30万', '家庭出行'], creator: '李倩', updatedAt: '昨天 14:05', status: '启用', source: '历史调研样本库' },
  { id: 'U-10007', phone: '137****6082', name: '宋景行', tags: ['城市', '科技引领消费', '20-30万', '汽车垂媒', '自驾'], creator: '王珂', updatedAt: '07-16 19:33', status: '启用', source: '富通 VOC 观点库' },
  { id: 'U-10008', phone: '132****4971', name: '韩芷晴', tags: ['25岁', '单身', '地铁', '15-18万'], creator: '张明', updatedAt: '07-16 15:17', status: '启用', source: '是通科技基础属性标签库' },
  { id: 'U-10009', phone: '155****0184', name: '许嘉树', tags: ['本科', '品质消费', '20-30万', '自驾'], creator: '孙悦', updatedAt: '07-15 20:08', status: '启用', source: '是通科技购车意向标签库' },
  { id: 'U-10010', phone: '181****3457', name: '沈知夏', tags: ['15-18万', '单身', '城市', '计划首购'], creator: '赵宁', updatedAt: '07-15 17:26', status: '启用', source: '历史调研样本库' },
  { id: 'U-10011', phone: '173****6902', name: '何予川', tags: ['电动自行车', '计划换购', '汽车垂媒', '自驾'], creator: '王珂', updatedAt: '07-14 18:12', status: '停用', source: '是通科技运营商行为标签' },
  { id: 'U-10012', phone: '152****8675', name: '梁语桐', tags: ['已婚', '2人', '家庭出行', '20-30万', '自驾'], creator: '李倩', updatedAt: '07-14 11:49', status: '启用', source: '是通科技基础属性标签库' }
];

const generatedUserProfiles = [
  ['25岁', '女', '本科', '城市', '计划首购', '15-18万', '新能源车偏好', '预算15-25万', '一线/新一线城市', '电动车主/潜客', '通勤出行高频', '汽车垂媒高活跃', '尝鲜消费', '科技尝鲜者', '短视频平台', '地铁'],
  ['30岁', '男', '本科', '城市', '已婚', '是', '2人', '4人', '20-30万', '计划增购', '自驾', '家庭出行', '家庭首购换购', 'SUV偏好人群', '中高消费能力', '通勤出行高频', '品质消费', '1辆'],
  ['28岁', '男', '硕士及以上', '城市', '单身', '20-30万', '计划换购', '电动自行车', '科技尝鲜者', '汽车垂媒高活跃', '电动车主/潜客', '互联网/通信', '尝鲜消费', '自驾', '1-3年'],
  ['26岁', '女', '本科', '城市', '单身', '租房', '15-18万', '计划首购', '预算15-25万', '三线及以下潜客', '首次购车用户', '地铁', '价格敏感型用户', '谨慎消费', '性价比', '通勤出行高频'],
  ['33岁', '女', '本科', '城市', '已婚', '是', '3人以上', '6人', '家庭出行', '自驾', '20-30万', '计划增购', '中高消费能力', 'SUV偏好人群', '自有住房有贷款', '2辆'],
  ['35岁', '男', '本科', '城市', '已婚', '国有企业', '30-50万', '计划增购', '自驾', '中高消费能力', '品质消费', '高铁', '每月1次及以上', '通勤出行高频', '1辆'],
  ['24岁', '女', '大专', '城市', '单身', '租房', '15-18万', '计划首购', '地铁', '短视频平台', '潮流个性风', '动漫二次元', '自由行', '价格敏感型用户', '无车潜客'],
  ['29岁', '男', '本科', '城市', '单身', '20-30万', '计划首购', '电动自行车', '自驾', '1-3年', '汽车垂媒', '科技引领消费', '尝鲜消费', '互联网/通信', '新能源车偏好'],
  ['42岁', '女', '本科', '城市', '已婚', '是', '2人', '家庭出行', '20-30万', '自有住房无贷款', '谨慎消费', '性价比', '安全', '自驾', '计划换购'],
  ['31岁', '男', '本科', '城市', '单身', '20-30万', '计划增购', '自驾', '高铁', '每月1次及以上', '旅游出行偏好', '家庭出行', '汽车垂媒高活跃', '1辆'],
  ['58岁', '女', '退休人员', '城市', '已婚', '50万以上', '自有住房无贷款', '品质消费', '安全', '自驾', '计划换购', '2辆', '高铁'],
  ['27岁', '女', '本科', '城市', '单身', '租房', '15-18万', '地铁', '计划首购', '预算15-25万', '首次购车用户', '价格敏感型用户', '无车潜客', '通勤出行高频']
];

const userDataAssets = [
  ...seededUserDataAssets,
  ...Array.from({ length: 988 }, (_, index) => {
    const profileIndex = index % generatedUserProfiles.length;
    const serial = index + 10013;
    const surnames = ['陈', '林', '张', '王', '李', '赵', '周', '孙', '吴', '徐', '何', '郭'];
    const givenNames = ['知远', '语晨', '景行', '安然', '子涵', '书瑶', '明宇', '若琳', '嘉航', '清妍', '逸凡', '星河'];

    return {
      id: `U-${serial}`,
      phone: `1${30 + index % 60}****${String(1000 + index).slice(-4)}`,
      name: `${surnames[index % surnames.length]}${givenNames[(index * 3 + profileIndex) % givenNames.length]}`,
      tags: generatedUserProfiles[profileIndex],
      creator: ['张明', '李倩', '王珂', '赵宁'][index % 4],
      updatedAt: `07-${String(18 - index % 12).padStart(2, '0')} ${String(8 + index % 11).padStart(2, '0')}:${index % 2 ? '18' : '42'}`,
      status: index % 23 === 0 ? '停用' : '启用',
      source: '统一用户数据源'
    };
  })
];

const consumerTemplates = [
  {
    id: 'C-001',
    name: '25-35岁新能源潜客',
    source: '标签体系 + 用户数据',
    linkedTags: ['25-35岁', '新能源车偏好', '预算15-25万', '一线/新一线城市'],
    users: 1258000,
    coverage: '设计验证 / 购买意愿 / 价格敏感',
    status: '启用',
    description: '面向紧凑型纯电 SUV 的主力潜客，适合验证造型、卖点和价格阈值。'
  },
  {
    id: 'C-002',
    name: '家庭首购换购人群',
    source: '标签体系 + 历史调研样本库',
    linkedTags: ['家庭首购换购', 'SUV偏好人群', '中高消费能力', '通勤出行高频'],
    users: 812000,
    coverage: '配置偏好 / 空间需求 / 舒适配置',
    status: '启用',
    description: '强调空间、安全、舒适性与家庭场景，适合配置方案和选装包验证。'
  },
  {
    id: 'C-003',
    name: '科技尝鲜者',
    source: '标签体系 + 富通 VOC',
    linkedTags: ['科技尝鲜者', '汽车垂媒高活跃', '电动车主/潜客'],
    users: 326000,
    coverage: '智能座舱 / 智驾卖点 / 传播话术',
    status: '启用',
    description: '对智能座舱、辅助驾驶、数字体验敏感，适合模拟高感知卖点反馈。'
  },
  {
    id: 'C-004',
    name: '价格敏感型用户',
    source: '标签体系 + 历史价格敏感数据',
    linkedTags: ['预算15-25万', '首次购车用户', '三线及以下潜客'],
    users: 694000,
    coverage: '价格弹性 / 配置取舍 / 放弃原因',
    status: '待复核',
    description: '用于多价格点测试和减配风险评估，重点关注心理价格临界点。'
  },
  { id: 'C-005', name: '都市品质家庭', source: '标签体系 + 用户数据', linkedTags: ['已婚', '2人', '本科'], users: 548000, coverage: '家庭出行 / 舒适配置', status: '启用', description: '关注家庭出行品质和座舱舒适感受。' },
  { id: 'C-006', name: '首购通勤青年', source: '标签体系 + 用户数据', linkedTags: ['单身', '地铁', '15-18万'], users: 426000, coverage: '首购预算 / 通勤效率', status: '启用', description: '价格敏感、以城市通勤为核心购车诉求。' },
  { id: 'C-007', name: '中高收入增购人群', source: '标签体系 + 用户数据', linkedTags: ['30-50万', '计划增购', '国有企业'], users: 392000, coverage: '增购需求 / 品牌偏好', status: '启用', description: '具备增购能力，更重视品牌与综合体验。' },
  { id: 'C-008', name: '新手新能源车主', source: '标签体系 + 用户数据', linkedTags: ['1-3年', '自驾', '电动自行车'], users: 318000, coverage: '补能焦虑 / 智能体验', status: '待复核', description: '对新能源补能与智能配置有明确学习需求。' },
  { id: 'C-009', name: '多孩改善型家庭', source: '标签体系 + 用户数据', linkedTags: ['3人以上', '6人', '家庭出行'], users: 274000, coverage: '空间需求 / 选装配置', status: '启用', description: '优先考察大空间、安全和全家出行便利性。' },
  { id: 'C-010', name: '高频跨城出行者', source: '标签体系 + 用户数据', linkedTags: ['每月1次及以上', '高铁', '自驾'], users: 463000, coverage: '续航能力 / 长途出行', status: '启用', description: '看重长途续航、补能效率和高频出行可靠性。' },
  { id: 'C-011', name: '科技数码兴趣用户', source: '标签体系 + 用户数据', linkedTags: ['尝鲜消费', '互联网/通信', '本科'], users: 352000, coverage: '智能座舱 / 智驾卖点', status: '启用', description: '乐于体验新技术，重视智能化感知。' },
  { id: 'C-012', name: '稳健务实购车者', source: '标签体系 + 用户数据', linkedTags: ['谨慎消费', '性价比', '安全'], users: 618000, coverage: '价格策略 / 可靠性', status: '启用', description: '以可靠性和性价比为首要购车判断标准。' },
  { id: 'C-013', name: '潮流个性青年', source: '标签体系 + 用户数据', linkedTags: ['潮流个性风', '动漫二次元', '自由行'], users: 287000, coverage: '造型设计 / 传播话术', status: '待复核', description: '对造型、色彩与个性化表达更敏感。' },
  { id: 'C-014', name: '退休品质生活群体', source: '标签体系 + 用户数据', linkedTags: ['退休人员', '50万以上', '自有住房无贷款'], users: 231000, coverage: '舒适配置 / 安全体验', status: '启用', description: '强调舒适、易用和出行安全。' },
  { id: 'C-015', name: '城市租房潜客', source: '标签体系 + 用户数据', linkedTags: ['租房', '地铁', '单身'], users: 504000, coverage: '价格敏感 / 首购意愿', status: '启用', description: '预算受限，对金融方案与用车成本敏感。' }
];

const scenarioTemplates = scenarios.map((scenario, index) => ({
  id: `S-00${index + 1}`,
  scenarioId: scenario.id,
  name: scenario.name,
  stage: scenario.stage,
  input: scenario.inputTitle,
  question: scenario.defaultQuestion,
  outputs: '量化评分 / 人群切分 / 消费者原声 / 归因建议',
  analysisDimensions: index === 0 ? ['年龄段', '性别', '城市级别', '购车预算'] : ['年龄段', '家庭阶段', '购车预算', '新能源经验'],
  status: '启用'
}));

const accountNames = ['张明', '李倩', '王珂', '陈露', '赵宁', '孙悦', '周航', '陈杰', '林越', '杨帆', '何佳', '吴桐', '宋然', '高远', '杜晨', '叶澜', '顾言', '陆羽', '严雪', '方圆', '沈川', '唐婧', '白露', '冯宇', '钟晴', '韩松', '许诺', '梁辰', '邵敏', '乔安'];
const systemAccounts = accountNames.map((name, index) => ({ id: `U-${String(index + 1).padStart(4, '0')}`, name, role: ['产品经理', '配置策略', '市场洞察', '设计研究', '数据运营'][index % 5], status: index % 7 === 3 ? '停用' : '启用', lastLogin: index < 2 ? `今天 ${index ? '10:15' : '09:42'}` : `07-${String(18 - (index % 9)).padStart(2, '0')} ${String(9 + index % 10).padStart(2, '0')}:${index % 2 ? '18' : '42'}` }));

const systemRoles = [
  { name: '平台管理员', scope: '全部模块、账号、角色、日志', members: 3, status: '启用', modules: ['标签体系', '用户数据', '消费者库', '调研场景', '消费调研', '模拟问答', '系统设置'] },
  { name: '产品经理', scope: '消费调研、调研场景、消费者库、模拟问答', members: 12, status: '启用', modules: ['消费者库', '调研场景', '消费调研', '模拟问答'] },
  { name: '数据运营', scope: '标签体系、用户数据、消费者库', members: 7, status: '启用', modules: ['标签体系', '用户数据', '消费者库'] },
  { name: '只读访客', scope: '报告查看、模拟问答', members: 18, status: '启用', modules: ['消费调研', '模拟问答'] },
  ...['洞察平台主管', '调研运营', '标签管理员', '用户运营', '报告分析师', '场景配置师', '策略顾问', '访客研究员', '数据审计员', '业务观察员', '临时协作员'].map((name, index) => ({ name, scope: ['消费者库、调研场景', '标签体系、用户数据', '消费调研、报告查看'][index % 3], members: 2 + index * 3, status: index % 4 === 2 ? '停用' : '启用', modules: ['消费者库', '调研场景', '消费调研'].slice(0, 1 + index % 3) }))
];

const operationLogs = Array.from({ length: 30 }, (_, index) => ({ id: `LOG-${String(index + 1).padStart(4, '0')}`, user: accountNames[index % accountNames.length], menu: ['消费调研', '消费者库', '调研场景', '标签体系', '用户数据'][index % 5], action: ['查看报告', '启动调研', '导出报告', '编辑模板', '更新用户'][index % 5], time: index < 2 ? `今天 ${index ? '10:06' : '11:20'}` : `07-${String(18 - (index % 12)).padStart(2, '0')} ${String(8 + index % 11).padStart(2, '0')}:${index % 2 ? '18' : '42'}`, ip: `10.24.${String(8 + index % 6)}.${String(12 + index)}`, target: ['造型方向验证报告', '中配版配置组合偏好测试', '购买意愿与市占预测', '前脸设计验证模板', '消费者标签'][index % 5] }));

const qaHistoryRecords = [
  { id: 'QA-001', consumer: '25-35岁新能源潜客', topic: '20万定价接受度追问', question: '这款车20万你会考虑买吗？最大顾虑是什么？', turns: 4, savedAt: '今天 10:18', owner: '张明' },
  { id: 'QA-002', consumer: '家庭首购换购人群', topic: '后排娱乐屏必要性', question: '后排娱乐屏是否会提升家庭用户购买意愿？', turns: 3, savedAt: '昨天 17:40', owner: '李倩' },
  { id: 'QA-003', consumer: '科技尝鲜者', topic: '智能座舱卖点验证', question: '8295座舱和L2+智驾哪个更能打动你？', turns: 5, savedAt: '07-16 19:22', owner: '王珂' },
  { id: 'QA-004', consumer: '价格敏感型用户', topic: '18.5万价格下探', question: '如果价格降到18.5万，你的购买意愿会如何变化？', turns: 2, savedAt: '07-15 15:08', owner: '赵宁' }
];

function formatNumber(value) {
  return value.toLocaleString('zh-CN');
}

function App() {
  const [activePage, setActivePage] = useState('survey');
  const [activeScenario, setActiveScenario] = useState('design');
  const [activeStep, setActiveStep] = useState(1);
  const [tasks, setTasks] = useState(researchTasks);
  const [tagGroupList, setTagGroupList] = useState(tagGroups);
  const [taxonomyList, setTaxonomyList] = useState(taxonomySeed);
  const [userDataList, setUserDataList] = useState(userDataAssets);
  const [consumerTemplateList, setConsumerTemplateList] = useState(consumerTemplates);
  const [scenarioTemplateList, setScenarioTemplateList] = useState(scenarioTemplates);
  const [accountList, setAccountList] = useState(systemAccounts);
  const [roleList, setRoleList] = useState(systemRoles);
  const [logList, setLogList] = useState(operationLogs);
  const [selectedTags, setSelectedTags] = useState(['bev', 'budget-15-25', 'city-tier1', 'age-25-35', 'middle-high']);
  const [reportTab, setReportTab] = useState('overview');
  const [sampleSize, setSampleSize] = useState(1258);
  const [confidence, setConfidence] = useState(92);
  const [running, setRunning] = useState(false);
  const [taskName, setTaskName] = useState('2025款 智行 Compact EV SUV · 研究任务');
  const [taskDescription, setTaskDescription] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [reportTask, setReportTask] = useState(null);
  const [activeConsumerTemplate, setActiveConsumerTemplate] = useState(consumerTemplates[0].id);
  const [selectedConsumerTemplateIds, setSelectedConsumerTemplateIds] = useState([consumerTemplates[0].id]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState('accounts');

  const scenario = scenarios.find((item) => item.id === activeScenario);
  const selectedTagObjects = tagGroupList.flatMap((group) => group.tags).filter((tag) => selectedTags.includes(tag.id));
  const estimatedPool = selectedTagObjects.reduce((sum, tag) => sum + tag.size, 0);

  const sampleHealth = useMemo(() => {
    if (sampleSize >= 2000) return { label: '高置信', tone: 'good' };
    if (sampleSize >= 1000) return { label: '样本充足', tone: 'good' };
    if (sampleSize >= 500) return { label: '可发布', tone: 'warn' };
    return { label: '样本偏低', tone: 'risk' };
  }, [sampleSize]);

  function toggleTag(id) {
    setSelectedTags((current) => {
      if (current.includes(id)) return current.filter((item) => item !== id);
      return [...current, id];
    });
  }

  function appendLog(action, target) {
    setLogList((current) => [
      { time: '刚刚', user: '张明', action, target },
      ...current
    ]);
  }

  function openCreateResearch(task) {
    setActiveStep(1);
    if (task) {
      setTaskName(task.name);
      setActiveScenario(task.scenarioId);
      const matchedConsumer = consumerTemplateList.find((template) => template.name === task.consumer);
      if (matchedConsumer) {
        setActiveConsumerTemplate(matchedConsumer.id);
        setSelectedConsumerTemplateIds([matchedConsumer.id]);
      }
    } else {
      setTaskName('2025款 智行 Compact EV SUV · 研究任务');
      setTaskDescription('');
    }
    setCreateOpen(true);
  }

  function runSimulation() {
    setRunning(true);
    setActiveStep(3);
    setTimeout(() => {
      const selectedConsumers = consumerTemplateList.filter((template) => selectedConsumerTemplateIds.includes(template.id));
      const consumerTemplate = selectedConsumers[0] || consumerTemplateList.find((template) => template.id === activeConsumerTemplate);
      appendLog('启动调研', taskName);
      setTasks((current) => [
        {
          id: `T-${String(current.length + 1).padStart(3, '0')}`,
          name: taskName,
          scenarioId: activeScenario,
          status: '进行中',
          creator: '张明',
          sample: sampleSize,
          updatedAt: '刚刚',
          consumer: selectedConsumers.map((template) => template.name).join('、') || consumerTemplate.name,
          result: '已创建'
        },
        ...current
      ]);
      setRunning(false);
      setReportTab('overview');
      setCreateOpen(false);
      setActivePage('survey');
    }, 900);
  }

  function nextStep() {
    setActiveStep((current) => Math.min(3, current + 1));
  }

  function previousStep() {
    setActiveStep((current) => Math.max(1, current - 1));
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <img className="brand-mark" src={aiConsumerLogo} alt="AI消费者洞察平台" />
          <div>
            <strong>AI消费者洞察平台</strong>
            <span>Consumer Insight OS</span>
          </div>
        </div>
        <nav className="nav">
          {menuGroups.map((group, groupIndex) => (
            <div className="nav-group" key={group.parent || groupIndex}>
              {group.parent && <div className="nav-parent">{group.parent}</div>}
              {group.items.map(({ label, icon: Icon, page }) => (
                <button className={activePage === page ? 'active' : ''} onClick={() => setActivePage(page)} key={label}>
                  <Icon size={17} />
                  {label}
                </button>
              ))}
            </div>
          ))}
          <div className="nav-group conversation-group">
            <div className="nav-parent">问答记录</div>
            <div className="conversation-list">
              {qaHistoryRecords.map((record) => (
                <button
                  className="conversation-item"
                  onClick={() => setActivePage('qa')}
                  key={record.id}
                >
                  <History size={15} />
                  <span>{record.topic}</span>
                </button>
              ))}
            </div>
          </div>
        </nav>
        <div className="sidebar-footer">
          <div className="user-profile sidebar-user">
            <div className="avatar">李</div>
            <div>
              <strong>李建秋</strong>
              <span>产品经理</span>
            </div>
          </div>
          <button className="settings-entry" onClick={() => setSettingsOpen(true)} aria-label="系统设置">
            <Settings size={17} />
          </button>
        </div>
      </aside>

      <main className="workspace">
        <section className="main-page">
          {activePage === 'survey' && (
            <div className="survey-workspace">
              <TaskList tasks={tasks} setTasks={setTasks} setCreateOpen={openCreateResearch} setReportTask={setReportTask} appendLog={appendLog} />
            </div>
          )}
          {activePage === 'tags' && <TagSystemPage tagRows={taxonomyList} setTagRows={setTaxonomyList} tagGroups={tagGroupList} setTagGroups={setTagGroupList} consumerTemplates={consumerTemplateList} appendLog={appendLog} />}
          {activePage === 'users' && <UserDataPage userDataAssets={userDataList} setUserDataAssets={setUserDataList} tagRows={taxonomyList} appendLog={appendLog} />}
          {activePage === 'consumers' && <ConsumerLibraryPage templates={consumerTemplateList} setTemplates={setConsumerTemplateList} tagGroups={tagGroupList} tagRows={taxonomyList} userDataAssets={userDataList} tasks={tasks} qaRecords={qaHistoryRecords} logs={logList} appendLog={appendLog} />}
          {activePage === 'scenarios' && <ScenarioTemplatePage templates={scenarioTemplateList} setTemplates={setScenarioTemplateList} consumerTemplates={consumerTemplateList} appendLog={appendLog} />}
          {activePage === 'qa' && <SimulationQaPage consumerTemplates={consumerTemplateList} appendLog={appendLog} />}
        </section>

        {settingsOpen && (
          <SystemSettingsModal
            activePage={settingsTab}
            setActivePage={setSettingsTab}
            accounts={accountList}
            setAccounts={setAccountList}
            roles={roleList}
            setRoles={setRoleList}
            logs={logList}
            appendLog={appendLog}
            onClose={() => setSettingsOpen(false)}
          />
        )}

        {createOpen && (
          <CreateResearchModal
            activeStep={activeStep}
            setActiveStep={setActiveStep}
            activeScenario={activeScenario}
            setActiveScenario={setActiveScenario}
            scenario={scenario}
            selectedTags={selectedTags}
            setSelectedTags={setSelectedTags}
            toggleTag={toggleTag}
            selectedTagObjects={selectedTagObjects}
            activeConsumerTemplate={activeConsumerTemplate}
            setActiveConsumerTemplate={setActiveConsumerTemplate}
            selectedConsumerTemplateIds={selectedConsumerTemplateIds}
            setSelectedConsumerTemplateIds={setSelectedConsumerTemplateIds}
            consumerTemplates={consumerTemplateList}
            scenarioTemplates={scenarioTemplateList}
            tagGroups={tagGroupList}
            estimatedPool={estimatedPool}
            sampleSize={sampleSize}
            setSampleSize={setSampleSize}
            confidence={confidence}
            setConfidence={setConfidence}
            sampleHealth={sampleHealth}
            runSimulation={runSimulation}
            running={running}
            nextStep={nextStep}
            previousStep={previousStep}
            taskName={taskName}
            setTaskName={setTaskName}
            taskDescription={taskDescription}
            setTaskDescription={setTaskDescription}
            onManageScenarios={() => {
              setCreateOpen(false);
              setActivePage('scenarios');
            }}
            onClose={() => setCreateOpen(false)}
          />
        )}

        {reportTask && (
          <ReportDetailModal
            task={reportTask}
            reportTab={reportTab}
            setReportTab={setReportTab}
            selectedTagObjects={selectedTagObjects}
            sampleSize={reportTask.sample || sampleSize}
            onClose={() => setReportTask(null)}
          />
        )}
      </main>
    </div>
  );
}

function TaskList({ tasks, setTasks, setCreateOpen, setReportTask, appendLog }) {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('全部');
  const pageSize = 10;
  const filteredTasks = statusFilter === '全部' ? tasks : tasks.filter((task) => task.status === statusFilter);
  const pageCount = Math.max(1, Math.ceil(filteredTasks.length / pageSize));
  const pageTasks = filteredTasks.slice((page - 1) * pageSize, page * pageSize);

  function changeFilter(filter) {
    setStatusFilter(filter);
    setPage(1);
  }

  function updateTaskStatus(task, status, action) {
    setTasks((current) => current.map((item) => item.id === task.id ? { ...item, status, updatedAt: '刚刚' } : item));
    appendLog(action, task.name);
  }

  function deleteTask(task) {
    setTasks((current) => current.filter((item) => item.id !== task.id));
    appendLog('删除调研', task.name);
  }

  return (
    <div className="task-home">
      <PageIntro
        title="消费调研"
        filters={<div className="task-status-switch" role="tablist" aria-label="任务状态筛选">{['全部', '已完成', '进行中', '未开始'].map((status) => <button key={status} className={statusFilter === status ? 'active' : ''} onClick={() => changeFilter(status)}>{status}</button>)}</div>}
        actions={<button className="primary" onClick={() => setCreateOpen()}><Plus size={16} /> 新建调研</button>}
      />
      <div className="task-list-workbench">
        <div className="task-list-head"><span>任务编号</span><span>任务名称</span><span>调研场景</span><span>消费者</span><span>创建人</span><span>创建时间</span><span>任务状态</span><span>操作</span></div>
        <div className="list-body-scroll task-list-scroll">
        {pageTasks.map((task) => {
          const taskScenario = scenarios.find((item) => item.id === task.scenarioId);
          const StatusIcon = task.status === '已完成' ? Check : task.status === '进行中' ? Activity : TriangleAlert;
          return (
            <article className="task-list-row" key={task.id}>
              <span className="task-code">{task.id}</span><strong>{task.name}</strong><span>{taskScenario.name}</span><span>{task.consumer}</span><span>{task.creator}</span><span>{task.updatedAt}</span><span className={`status task-status ${task.status}`}><StatusIcon size={12} />{task.status}</span><div className="task-list-actions">
                {task.status === '未开始' && <><button className="text-button" onClick={() => updateTaskStatus(task, '进行中', '开始调研')}>开始任务</button><button className="text-button" onClick={() => setCreateOpen(task)}>编辑</button><button className="text-button danger" onClick={() => deleteTask(task)}>删除</button></>}
                {task.status === '进行中' && <button className="text-button danger" onClick={() => updateTaskStatus(task, '未开始', '中止调研')}>中止任务</button>}
                {task.status === '已完成' && <><button className="text-button" onClick={() => setReportTask(task)}>查看报告</button><button className="text-button danger" onClick={() => deleteTask(task)}>删除</button></>}
              </div>
            </article>
          );
        })}
        </div>
        <div className="pagination">
          <span>共 {filteredTasks.length} 条，每页 {pageSize} 条</span>
          <div>
            <button className="secondary small" onClick={() => setPage((current) => Math.max(1, current - 1))} disabled={page === 1}>上一页</button>
            {Array.from({ length: pageCount }, (_, index) => index + 1).map((item) => (
              <button className={page === item ? 'page-number active' : 'page-number'} onClick={() => setPage(item)} key={item}>{item}</button>
            ))}
            <button className="secondary small" onClick={() => setPage((current) => Math.min(pageCount, current + 1))} disabled={page === pageCount}>下一页</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function TagSystemPage({ tagRows, setTagRows, tagGroups, setTagGroups, consumerTemplates, appendLog }) {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('全部标签');
  const [statusFilter, setStatusFilter] = useState('全部状态');
  const [categoryFilter, setCategoryFilter] = useState('全部一级标签');
  const [builderOpen, setBuilderOpen] = useState(false);
  const [editingTag, setEditingTag] = useState(null);
  const [page, setPage] = useState(1);
  const [notice, setNotice] = useState('');
  const keyword = query.trim();
  const categories = Array.from(new Set(tagRows.map((item) => item.category)));
  const categoryIconMap = { '全部标签': Grid2X2, '个人属性': UserRound, '家庭属性': UsersRound, '经济属性': CircleDollarSign, '偏好属性': Star, '出行属性': Activity, '拥车属性': Gauge, '最近一次购车情况': BadgeDollarSign };
  const categoryItems = [{ label: '全部标签', count: tagRows.length }, ...categories.filter((category) => category !== '最近一次购车情况').map((category) => ({ label: category, count: tagRows.filter((item) => item.category === category).length }))];
  const filteredRows = tagRows.filter((item) => {
    const matchesTab = activeCategory === '全部标签' || item.category === activeCategory;
    const matchesCategory = categoryFilter === '全部一级标签' || item.category === categoryFilter;
    const matchesStatus = statusFilter === '全部状态' || item.status === statusFilter;
    const matchesQuery = !keyword || `${item.category}${item.name}${item.id}${item.content}${item.definition}${item.synonyms}`.includes(keyword);
    return matchesTab && matchesCategory && matchesStatus && matchesQuery;
  });
  const { items: pageRows, pageCount, page: currentPage } = paginate(filteredRows, page, 20);

  function applyFilter(callback) {
    callback();
    setPage(1);
  }

  function saveTag(tag) {
    setTagRows((current) => {
      const exists = current.some((item) => item.id === tag.id);
      if (exists) return current.map((item) => (item.id === tag.id ? tag : item));
      return [{ ...tag, id: `TAX-${String(current.length + 1).padStart(3, '0')}` }, ...current];
    });
    appendLog(editingTag?.id ? '编辑标签' : '新增标签', tag.name);
    setEditingTag(null);
    setNotice(`${tag.name} 已保存`);
  }

  function deleteTag(tag) {
    if (tag.status === '启用') return;
    setTagRows((current) => current.filter((item) => item.id !== tag.id));
    appendLog('删除标签', tag.name);
    setNotice(`${tag.name} 已删除`);
  }
  function saveTagGroup(form) {
    const newGroup = {
      group: form.group,
      tags: form.tags.map((tag, index) => ({
        id: `${form.group}-${index}`.replace(/\s+/g, '-'),
        name: tag,
        size: 120000 + index * 68000
      }))
    };
    setTagGroups((current) => [newGroup, ...current]);
    appendLog('维护标签', newGroup.group);
    setBuilderOpen(false);
  }

  return (
    <div className="asset-page taxonomy-page">
      <PageIntro
        title="标签体系"
        filters={<div className="filter-controls">
          <div className="search-field">
            <Search size={16} />
            <input value={query} onChange={(event) => applyFilter(() => setQuery(event.target.value))} placeholder="搜索标签名称、编码或内容" />
          </div>
          <HeaderFilterSelect value={statusFilter} onChange={(event) => applyFilter(() => setStatusFilter(event.target.value))}>
            <option>全部状态</option>
            <option>启用</option>
            <option>停用</option>
          </HeaderFilterSelect>
          <HeaderFilterSelect value={categoryFilter} onChange={(event) => applyFilter(() => { setCategoryFilter(event.target.value); setActiveCategory('全部标签'); })}>
            <option>全部一级标签</option>
            {categories.map((category) => <option key={category}>{category}</option>)}
          </HeaderFilterSelect>
        </div>}
        actions={<button className="secondary" onClick={() => { appendLog('导出标签', `${filteredRows.length} 条标签`); setNotice(`已生成 ${filteredRows.length} 条标签导出任务`); }}><Download size={15} /> 导出标签</button>}
      />
      {notice && <div className="inline-success">{notice}</div>}
      <div className="taxonomy-category-tabs" aria-label="一级标签分类">
        {categoryItems.map((item) => { const Icon = categoryIconMap[item.label] || Grid2X2; return <button className={activeCategory === item.label ? 'active' : ''} onClick={() => applyFilter(() => { setActiveCategory(item.label); setCategoryFilter('全部一级标签'); })} key={item.label}><span className="taxonomy-category-icon"><Icon size={16} /></span><span className="taxonomy-category-copy"><strong>{item.label}</strong><small>{item.count} 个标签</small></span></button>; })}
      </div>
      <div className="taxonomy-table">
        <div className="taxonomy-table-row table-head">
          <span>一级分类</span>
          <span>标签名称</span>
          <span>标签编码</span>
          <span>标签内容</span>
          <span>标签状态</span>
          <span className="sticky-action">操作</span>
        </div>
        <div className="list-body-scroll">
        {pageRows.map((item) => (
          <div className="taxonomy-table-row" key={item.id}>
            <span className="taxonomy-category-cell">{item.category}</span>
            <strong>{item.name}</strong>
            <span>{item.id}</span>
            <div className="table-tags taxonomy-content-tags">
              {item.values.slice(0, 4).map((value) => <span key={value}>{value}</span>)}
              {item.values.length > 4 && <span>+{item.values.length - 4}项</span>}
            </div>
            <span className={`status ${item.status}`}>{item.status}</span>
            <div className="row-action-buttons sticky-action">
              <button className="text-button" onClick={() => setEditingTag(item)}><Pencil size={14} /> 编辑</button>
              <button className="text-button danger" disabled={item.status === '启用'} title={item.status === '启用' ? '请先停用标签后再删除' : '删除标签'} onClick={() => deleteTag(item)}><Trash2 size={14} /> 删除</button>
            </div>
          </div>
        ))}
        {!filteredRows.length && <div className="taxonomy-empty"><Search size={22} /><strong>没有找到匹配标签</strong><span>试试搜索“购车”“家庭”或“城市”</span></div>}
        </div>
        <Pagination total={filteredRows.length} page={currentPage} pageCount={pageCount} onPageChange={setPage} />
      </div>
      {builderOpen && <TagGroupBuilder onClose={() => setBuilderOpen(false)} onSave={saveTagGroup} />}
      {editingTag && <TagEditorModal tag={editingTag} categories={categories} onClose={() => setEditingTag(null)} onSave={saveTag} />}
    </div>
  );
}

function UserDataPage({ userDataAssets, setUserDataAssets, tagRows, appendLog }) {
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('全部状态');
  const [categoryFilter, setCategoryFilter] = useState('全部一级分类');
  const [editingUser, setEditingUser] = useState(null);
  const [expandedUserId, setExpandedUserId] = useState(null);
  const [page, setPage] = useState(1);
  const [notice, setNotice] = useState('');
  const categories = Array.from(new Set(tagRows.map((row) => row.category)));
  const userGridColumns = `112px 126px minmax(220px, 260px) ${categories.map(() => '108px').join(' ')} 100px 76px 96px`;
  const userTableMinWidth = 770 + categories.length * 108;
  const filteredUsers = userDataAssets.filter((user) => {
    const keyword = query.trim();
    const matchesQuery = !keyword || [user.id, user.phone, user.name, user.creator, ...user.tags].some((value) => value.includes(keyword));
    const matchesStatus = statusFilter === '全部状态' || user.status === statusFilter;
    const matchesCategory = categoryFilter === '全部一级分类' || Boolean(groupUserTagsByCategory(user.tags, tagRows)[categoryFilter]);
    return matchesQuery && matchesStatus && matchesCategory;
  });
  const { items: pageUsers, pageCount, page: currentPage } = paginate(filteredUsers, page, 20);

  function applyFilter(callback) {
    callback();
    setPage(1);
  }

  function saveUser(form) {
    const normalized = {
      ...form,
      id: form.id || `U-${String(userDataAssets.length + 10001).padStart(5, '0')}`,
      creator: form.creator || '张明',
      updatedAt: '刚刚',
      source: form.source || '手动新增'
    };
    setUserDataAssets((current) => {
      const exists = current.some((user) => user.id === normalized.id);
      if (exists) return current.map((user) => (user.id === normalized.id ? normalized : user));
      return [normalized, ...current];
    });
    appendLog(form.id ? '编辑用户' : '新增用户', normalized.name);
    setEditingUser(null);
    setNotice(form.id ? '用户信息已更新' : '新增用户已保存');
  }

  function importUsers() {
    const imported = [
      { id: `U-${String(userDataAssets.length + 10001).padStart(5, '0')}`, phone: '136****9021', name: '唐嘉言', tags: ['新能源车偏好', '预算15-25万', '一线/新一线城市'], creator: '张明', updatedAt: '刚刚', status: '启用', source: '批量导入' },
      { id: `U-${String(userDataAssets.length + 10002).padStart(5, '0')}`, phone: '147****3168', name: '罗清禾', tags: ['家庭首购换购', '通勤出行高频', '中高消费能力'], creator: '张明', updatedAt: '刚刚', status: '启用', source: '批量导入' }
    ];
    setUserDataAssets((current) => [...imported, ...current]);
    appendLog('导入用户', '批量导入 2 条用户数据');
    setNotice('已导入 2 条用户数据');
  }

  function exportUsers() {
    appendLog('导出用户', `${filteredUsers.length} 条用户数据`);
    setNotice(`已生成 ${filteredUsers.length} 条用户数据导出任务`);
  }

  function deleteUser(user) {
    setUserDataAssets((current) => current.filter((item) => item.id !== user.id));
    appendLog('删除用户', user.name);
    setNotice(`${user.name} 已从用户列表移除`);
  }

  return (
    <div className="asset-page">
      <PageIntro
        title="用户数据"
        filters={<div className="filter-controls">
          <div className="search-field">
            <Search size={16} />
            <input value={query} onChange={(event) => applyFilter(() => setQuery(event.target.value))} placeholder="搜索用户ID、手机号、姓名、标签" />
          </div>
          <HeaderFilterSelect value={statusFilter} onChange={(event) => applyFilter(() => setStatusFilter(event.target.value))}>
            <option>全部状态</option>
            <option>启用</option>
            <option>停用</option>
          </HeaderFilterSelect>
          <HeaderFilterSelect value={categoryFilter} onChange={(event) => applyFilter(() => setCategoryFilter(event.target.value))}>
            <option>全部一级分类</option>
            {categories.map((category) => <option key={category}>{category}</option>)}
          </HeaderFilterSelect>
        </div>}
        actions={<><button className="secondary" onClick={importUsers}><Upload size={15} /> 导入</button><button className="secondary" onClick={exportUsers}><Download size={15} /> 导出</button><button className="primary" onClick={() => setEditingUser({})}><Plus size={16} /> 新增用户</button></>}
      />
      {notice && <div className="inline-success">{notice}</div>}
      <div className="user-table user-data-list">
        <div className="table-scroll-x">
        <div className="user-row table-head" style={{ gridTemplateColumns: userGridColumns, minWidth: userTableMinWidth }}>
          <span>用户</span>
          <span>联系方式</span>
          <span>画像摘要</span>
          {categories.map((category) => <span key={category}>{category}</span>)}
          <span>更新时间</span>
          <span>状态</span>
          <span className="sticky-action">操作</span>
        </div>
        <div className="list-body-scroll" style={{ minWidth: userTableMinWidth }}>
        {pageUsers.map((user) => {
          const presentation = buildUserDataPresentation(user, tagRows);
          const categoryMap = new Map(presentation.categories.map((item) => [item.category, item]));
          const isExpanded = expandedUserId === user.id;
          return <React.Fragment key={user.id}>
            <div className={`user-row user-data-row${isExpanded ? ' expanded' : ''}`} style={{ gridTemplateColumns: userGridColumns, minWidth: userTableMinWidth }}>
              <div className="user-identity-cell"><button className={`user-expand-toggle${isExpanded ? ' open' : ''}`} onClick={() => setExpandedUserId(isExpanded ? null : user.id)} aria-label={isExpanded ? `收起 ${user.name} 的标签详情` : `展开 ${user.name} 的标签详情`}><ChevronRight size={15} /></button><strong>{user.name}</strong><span>{user.id}</span></div>
              <span>{user.phone}</span>
              <div className="user-profile-summary"><strong>{presentation.summary || '暂无标签'}</strong><div>{presentation.chips.map((tag) => <span key={tag}>{tag}</span>)}{presentation.remaining > 0 && <em>+{presentation.remaining}</em>}</div></div>
              {categories.map((category) => {
                const categoryData = categoryMap.get(category);
                return <div className="user-category-field" key={category}>{categoryData ? <span title={categoryData.details.join('\n')}>{categoryData.count} 个标签</span> : <em>—</em>}</div>;
              })}
              <span>{user.updatedAt}</span>
              <div className="user-status-cell"><span className={`status ${user.status}`}>{user.status}</span></div>
              <div className="row-action-buttons sticky-action"><button className="text-button" onClick={() => setEditingUser(user)}><Pencil size={14} /> 编辑</button><button className="text-button danger" onClick={() => deleteUser(user)}><Trash2 size={14} /> 删除</button></div>
            </div>
            {isExpanded && <div className="user-expanded-row" style={{ gridTemplateColumns: userGridColumns, minWidth: userTableMinWidth }}><div className="user-expanded-tags">{categories.map((category) => {
              const categoryData = categoryMap.get(category);
              return <section key={category}><strong>{category}</strong>{categoryData ? <div>{categoryData.details.map((tag) => <span key={tag}>{tag}</span>)}</div> : <em>暂无标签</em>}</section>;
            })}</div></div>}
          </React.Fragment>;
        })}
        </div>
        </div>
        <Pagination total={filteredUsers.length} page={currentPage} pageCount={pageCount} onPageChange={setPage} />
      </div>
      {editingUser && <UserBuilder user={editingUser} tagRows={tagRows} onClose={() => setEditingUser(null)} onSave={saveUser} />}
    </div>
  );
}

function ConsumerLibraryPage({ templates, setTemplates, tagGroups, tagRows, userDataAssets, tasks, qaRecords, logs, appendLog }) {
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('全部状态');
  const [detailTemplate, setDetailTemplate] = useState(null);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [builderOpen, setBuilderOpen] = useState(false);
  const filteredTemplates = templates.filter((template) => {
    const keyword = query.trim();
    const matchesQuery = !keyword || [template.id, template.name, template.description, ...template.linkedTags].some((value) => value.includes(keyword));
    const matchesStatus = statusFilter === '全部状态' || template.status === statusFilter;
    return matchesQuery && matchesStatus;
  });

  function saveTemplate(form) {
    const newTemplate = {
      id: form.id || `C-${String(templates.length + 1).padStart(3, '0')}`,
      name: form.name,
      source: form.source,
      linkedTags: form.linkedTags,
      users: form.users,
      sample: form.sample,
      coverage: form.coverage,
      status: '启用',
      description: form.description
    };
    setTemplates((current) => form.id ? current.map((item) => item.id === form.id ? newTemplate : item) : [newTemplate, ...current]);
    appendLog('维护消费者模板', newTemplate.name);
    setBuilderOpen(false);
    setEditingTemplate(null);
  }

  return (
    <div className="asset-page">
      <PageIntro
        title="消费者库"
        filters={<div className="filter-controls"><div className="search-field">
          <Search size={16} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索模板名称、标签或适配场景" />
        </div><HeaderFilterSelect value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
          <option>全部状态</option>
          <option>启用</option>
          <option>待复核</option>
        </HeaderFilterSelect></div>}
        actions={<button className="primary" onClick={() => setBuilderOpen(true)}><Plus size={16} /> 新建消费者</button>}
      />
      <div className="template-grid">
        {filteredTemplates.map((template) => {
          const tagSummary = summarizeTags(template.linkedTags);
          return <article className="template-card selectable" key={template.id}>
            <div className="asset-card-head">
              <div>
                <small>{template.id}</small>
                <strong>{template.name}</strong>
              </div>
              <span className={`status ${template.status}`}>{template.status}</span>
            </div>
            <p>{template.description}</p>
            <div className="chips template-tags">
              {tagSummary.visible.map((tag) => <span key={tag}>{tag}</span>)}
              {tagSummary.remaining > 0 && <span className="tag-overflow">+{tagSummary.remaining}</span>}
            </div>
            <div className="template-foot">
              <span><UsersRound size={14} />{formatNumber(template.users)}</span>
              <span><UserRound size={14} />{template.creator || '张明'}</span>
            </div>
            <div className="template-actions"><button className="text-button" onClick={() => setDetailTemplate(template)}>查看</button><button className="text-button" onClick={() => { setEditingTemplate(template); setBuilderOpen(true); }}>编辑</button></div>
          </article>;
        })}
      </div>
      {detailTemplate && <ConsumerTemplateDetailModal template={detailTemplate} users={userDataAssets} tagRows={tagRows} tasks={tasks} qaRecords={qaRecords} logs={logs} onClose={() => setDetailTemplate(null)} onEdit={() => { setEditingTemplate(detailTemplate); setDetailTemplate(null); setBuilderOpen(true); }} />}
      {builderOpen && <ConsumerTemplateBuilder template={editingTemplate} tagGroups={tagGroups} userDataAssets={userDataAssets} onClose={() => { setBuilderOpen(false); setEditingTemplate(null); }} onSave={saveTemplate} />}
    </div>
  );
}

function ScenarioTemplatePage({ templates, setTemplates, consumerTemplates, appendLog }) {
  const [query, setQuery] = useState('');
  const [stageFilter, setStageFilter] = useState('全部阶段');
  const [detailTemplate, setDetailTemplate] = useState(null);
  const [builderOpen, setBuilderOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const stages = Array.from(new Set(templates.map((template) => template.stage)));
  const filteredTemplates = templates.filter((template) => {
    const keyword = query.trim();
    const matchesQuery = !keyword || [template.id, template.name, template.question, template.input, template.outputs].some((value) => value.includes(keyword));
    const matchesStage = stageFilter === '全部阶段' || template.stage === stageFilter;
    return matchesQuery && matchesStage;
  });

  function saveTemplate(form) {
    const newTemplate = {
      id: form.id || `S-${String(templates.length + 1).padStart(3, '0')}`,
      scenarioId: form.scenarioId,
      name: form.name,
      stage: form.stage,
      input: form.input,
      question: form.question,
      outputs: form.outputs,
      analysisDimensions: form.analysisDimensions || analysisDimensionOptions.slice(0, 4),
      status: form.status || '启用'
    };
    setTemplates((current) => current.some((item) => item.id === newTemplate.id)
      ? current.map((item) => item.id === newTemplate.id ? newTemplate : item)
      : [newTemplate, ...current]);
    appendLog('维护场景模板', newTemplate.name);
    setBuilderOpen(false);
    setEditingTemplate(null);
  }

  function deleteTemplate(template) {
    setTemplates((current) => current.filter((item) => item.id !== template.id));
    appendLog('删除场景模板', template.name);
  }

  return (
    <div className="asset-page">
      <PageIntro
        title="调研场景"
        filters={<div className="filter-controls"><div className="search-field">
          <Search size={16} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索场景名称、输入结构或默认问题" />
        </div><HeaderFilterSelect value={stageFilter} onChange={(event) => setStageFilter(event.target.value)}>
          <option>全部阶段</option>
          {stages.map((stage) => <option key={stage}>{stage}</option>)}
        </HeaderFilterSelect></div>}
        actions={<button className="primary" onClick={() => setBuilderOpen(true)}><Plus size={16} /> 新建场景</button>}
      />
      <div className="scenario-list template-grid">
        {filteredTemplates.map((template) => (
          <article className="template-card scenario-card" key={template.id}>
            <div className="asset-card-head"><div className="scenario-card-title"><span className="scenario-icon"><ClipboardList size={16} /></span><div><small>{template.id} · {template.stage}</small><strong>{template.name}</strong></div></div><span className={`status ${template.status}`}>{template.status}</span></div>
            <p>{template.question}</p>
            <div className="scenario-meta"><span>输入：{template.input}</span><span>输出：{template.outputs}</span></div>
            <div className="template-actions" aria-label={`${template.name} 操作`}>
              <button className="text-button" onClick={() => setDetailTemplate(template)}>查看</button>
              <button className="text-button" onClick={() => { setEditingTemplate(template); setBuilderOpen(true); }}>编辑</button>
              <button className="text-button danger-text" onClick={() => deleteTemplate(template)}>删除</button>
            </div>
          </article>
        ))}
      </div>
      {detailTemplate && <ScenarioTemplateDetailModal template={detailTemplate} consumerTemplates={consumerTemplates} onClose={() => setDetailTemplate(null)} />}
      {builderOpen && <ScenarioTemplateBuilder template={editingTemplate} onClose={() => { setBuilderOpen(false); setEditingTemplate(null); }} onSave={saveTemplate} />}
    </div>
  );
}

function SimulationQaPage({ consumerTemplates, appendLog }) {
  const [selectedConsumer, setSelectedConsumer] = useState(consumerTemplates[0].id);
  const [qaInput, setQaInput] = useState('');
  const [result, setResult] = useState(null);
  const [savedSessions] = useState([
    { id: 'QA-001', consumer: '25-35岁新能源潜客', topic: '20万定价接受度追问', turns: 4, savedAt: '今天 10:18' },
    { id: 'QA-002', consumer: '家庭首购换购人群', topic: '后排娱乐屏必要性', turns: 3, savedAt: '昨天 17:40' }
  ]);
  const [messages, setMessages] = useState([]);
  const [insightOpen, setInsightOpen] = useState(false);
  const [insightWidth, setInsightWidth] = useState(360);
  const [sessionTitle, setSessionTitle] = useState('新建消费者问答');
  const [editingTitle, setEditingTitle] = useState(false);
  const consumer = consumerTemplates.find((item) => item.id === selectedConsumer);
  const suggestionCards = [
    { title: '20万售价是否会进入考虑清单？', consumer: '20万级新能源SUV年轻家庭用户' },
    { title: '哪个配置最影响购买意愿？', consumer: '智能化偏好用户' },
    { title: '相比竞品最大的顾虑是什么？', consumer: '价格敏感型首购用户' },
    { title: '哪些卖点最适合上市传播？', consumer: '年轻家庭用户' }
  ];
  const factors = [
    ['价格', 28],
    ['续航', 22],
    ['品牌信任', 18],
    ['智能座舱', 16],
    ['空间舒适', 10],
    ['智驾', 6]
  ];

  function buildAnswer(text) {
    if (consumer.name.includes('价格')) {
      return '20万处于可接受区间，但超过 21 万会明显拉低意愿；若能提供清晰的金融权益、续航保障和竞品优势，仍会进入对比清单。';
    }
    if (consumer.name.includes('家庭')) {
      return '家庭用户会优先判断安全、空间、续航和补能便利性。20万若能覆盖座椅舒适、儿童场景和基础智驾，会愿意进一步试驾。';
    }
    if (text.includes('配置')) {
      return '智能座舱、L2+ 智驾、600km 续航和座椅舒适配置最能提升购买意愿；后排娱乐屏更适合作为家庭选装，而不是全系强推。';
    }
    return '购买意愿：中高。20万处于可接受区间，会愿意进一步了解或试驾；核心顾虑集中在真实续航、品牌可靠性、售后网络和同价位竞品优惠。';
  }

  function sendQuestion(textOverride) {
    const text = (textOverride || qaInput).trim();
    if (!text) return;
    const answer = buildAnswer(text);
    const replyId = `reply-${Date.now()}`;
    setMessages((current) => [...current, { role: 'user', text, userName: '李建秋' }, { id: replyId, role: 'bot', text: '', thinking: true, thinkingStage: 1 }]);
    if (!messages.some((message) => message.role === 'user')) setSessionTitle(text.slice(0, 38));
    setResult({ question: text, answer });
    setQaInput('');
    appendLog('模拟问答', `${consumer.name} · ${text.slice(0, 18)}`);
    setTimeout(() => setMessages((current) => current.map((message) => message.id === replyId ? { ...message, thinkingStage: 2 } : message)), 1500);
    setTimeout(() => setMessages((current) => current.map((message) => message.id === replyId ? { ...message, thinkingStage: 3 } : message)), 3000);
    setTimeout(() => {
      let length = 0;
      const timer = setInterval(() => {
        length += 1;
        setMessages((current) => current.map((message) => message.id === replyId ? { ...message, thinking: false, text: answer.slice(0, length) } : message));
        if (length >= answer.length) clearInterval(timer);
      }, 26);
    }, 5000);
  }

  function beginInsightResize(event) {
    event.preventDefault();
    const handle = event.currentTarget;
    const startX = event.clientX;
    const startWidth = insightWidth;
    handle.setPointerCapture(event.pointerId);

    function resize(moveEvent) {
      setInsightWidth(Math.min(520, Math.max(280, startWidth + startX - moveEvent.clientX)));
    }

    function stop() {
      handle.removeEventListener('pointermove', resize);
      handle.removeEventListener('pointerup', stop);
      handle.removeEventListener('pointercancel', stop);
    }

    handle.addEventListener('pointermove', resize);
    handle.addEventListener('pointerup', stop);
    handle.addEventListener('pointercancel', stop);
  }

  if (!result) {
    return (
      <div className="qa-experience qa-landing">
        <section className="qa-centered">
          <div className="qa-hero-copy">
            <img className="qa-hero-logo" src={aiConsumerLogo} alt="" />
            <div>
              <h2>向AI消费者快速提问</h2>
              <p>输入产品方案、价格、配置或卖点，快速获得目标消费者反馈与归因。</p>
            </div>
          </div>
          <section className="quick-prompt">
            <textarea
              value={qaInput}
              onChange={(event) => setQaInput(event.target.value)}
              placeholder="输入你的问题，或粘贴车型方案、配置、价格点..."
              aria-label="模拟问答问题"
            />
            <div className="prompt-actions">
              <select value={selectedConsumer} onChange={(event) => setSelectedConsumer(event.target.value)}>
                {consumerTemplates.map((template) => <option value={template.id} key={template.id}>{template.name}</option>)}
              </select>
              <div className="prompt-tools">
                <button className="icon-button" aria-label="新增变量"><Plus size={20} /></button>
                <button className="icon-button" aria-label="上传附件"><Paperclip size={20} /></button>
                <button className="icon-button" aria-label="模板库"><Grid2X2 size={20} /></button>
                <button className="primary send-button" onClick={() => sendQuestion()}><Send size={20} /> 发送</button>
              </div>
            </div>
          </section>
          <section className="qa-suggestion-section">
            <div className="section-heading compact">
              <h2>快捷提问</h2>
            </div>
          <div className="suggestion-grid">
            {suggestionCards.map(({ title, consumer: cardConsumer }) => (
              <button className="suggestion-card" key={title} onClick={() => setQaInput(title)}>
                <strong>{title}</strong>
                <small>{cardConsumer}</small>
                <ChevronRight size={20} />
                </button>
              ))}
            </div>
          </section>
        </section>
      </div>
    );
  }

  return (
    <div className="qa-experience qa-result-page">
      <div className="qa-command-bar">{editingTitle ? <input autoFocus value={sessionTitle} onChange={(event) => setSessionTitle(event.target.value)} onBlur={() => setEditingTitle(false)} onKeyDown={(event) => event.key === 'Enter' && setEditingTitle(false)} aria-label="编辑问答标题" /> : <button className="qa-title-edit" onClick={() => setEditingTitle(true)} title="编辑标题">{sessionTitle}</button>}<button className="icon-button" onClick={() => setInsightOpen((value) => !value)} aria-label="切换归因侧边栏"><SlidersHorizontal size={18} /></button></div>
      <div className={`qa-result-content ${insightOpen ? 'with-insight' : ''}`} style={insightOpen ? { '--insight-panel-width': `${insightWidth}px` } : undefined}>
      <section className="qa-result-main">
        <div className="qa-message-stream">
          {messages.map((message, index) => message.role === 'user' ? <article className="chat-message user-message" key={`${message.text}-${index}`}><div className="user-round">李</div><div><div className="chat-sender">{message.userName}</div><div className="chat-bubble">{message.text}</div></div></article> : <article className="chat-message ai-message" key={`${message.text}-${index}`}>
          <div className="answer-head">
            <span className="answer-icon"><UsersRound size={24} /></span>
            <div>
              <strong>{consumer.name}（3213）</strong>
            </div>
          </div>
          <details className="ai-thinking" open={message.thinking}><summary>{message.thinking ? '正在思考…' : '已完成分析过程'}</summary><ol><li className={message.thinkingStage >= 1 ? 'streamed' : ''}><strong>画像与意图匹配</strong><span>该消费者处于 15–25 万预算区间，新能源偏好与一线城市通勤场景，使其先关注续航、补能和智能座舱的日常价值。</span><em>判断：产品方向与核心需求匹配。</em></li><li className={message.thinkingStage >= 2 ? 'streamed' : ''}><strong>价格与替代方案评估</strong><span>20 万未超过其心理上限，但会同时比较同价位车型的真实续航、金融权益和售后覆盖；价格优势不足以单独促成决策。</span><em>判断：需要用配置与保障降低比较成本。</em></li><li className={message.thinkingStage >= 3 ? 'streamed' : ''}><strong>形成购买条件</strong><span>如果续航表现、座舱体验与售后承诺被清晰证明，用户愿意进入试驾和横向对比；超过 22 万则会明显降低意愿。</span><em>判断：中高购买意愿，建议主推中配组合。</em></li></ol></details>
          {!message.thinking && message.text && <div className="chat-bubble ai-conclusion"><strong>最终结论</strong><p>{message.text}</p></div>}
        </article>)}
        </div>
        <section className="quick-prompt followup">
          <textarea
            value={qaInput}
            onChange={(event) => setQaInput(event.target.value)}
            placeholder="继续追问，例如：如果降到18.5万你的意愿会变化吗？"
            aria-label="继续追问"
          />
          <div className="prompt-actions">
            <select value={selectedConsumer} onChange={(event) => setSelectedConsumer(event.target.value)}>
              {consumerTemplates.map((template) => <option value={template.id} key={template.id}>{template.name}</option>)}
            </select>
            <div className="prompt-tools">
              <button className="icon-button" aria-label="新增变量"><Plus size={20} /></button>
              <button className="icon-button" aria-label="上传附件"><Paperclip size={20} /></button>
              <button className="icon-button" aria-label="模板库"><Grid2X2 size={20} /></button>
              <button className="primary send-button" onClick={() => sendQuestion()}><Send size={20} /> 发送</button>
            </div>
          </div>
        </section>
      </section>
      {insightOpen && <><div className="qa-insight-resize-handle" role="separator" aria-label="调整归因侧边栏宽度" aria-orientation="vertical" onPointerDown={beginInsightResize} />
      <aside className="qa-insight-panel" aria-label="归因分析侧边栏">
        <div className="panel-head">
          <strong>归因分析</strong>
        </div>
        <div className="analysis-section">
          <h3>标签依据</h3>
          <div className="chips">
            {consumer.linkedTags.map((tag) => <span key={tag}>{tag}</span>)}
          </div>
        </div>
        <div className="analysis-section">
          <h3>决策因素</h3>
          {factors.map(([label, value]) => (
            <div className="factor-row" key={label}>
              <span>{label}</span>
              <div><i style={{ width: `${value * 3}%` }} /></div>
              <strong>{value}%</strong>
            </div>
          ))}
        </div>
        <div className="analysis-section">
          <h3>归因解释</h3>
          <p>该消费者对20万价格处于可接受区间，续航和座舱形成正向驱动；但品牌信任与竞品替代风险会影响最终下单。</p>
        </div>
        <div className="analysis-section"><h3>深度归因</h3><div className="attribution-stack"><div><strong>正向驱动</strong><span>价格处于预算区间；600km续航与智能座舱共同提升试驾意愿。</span></div><div><strong>阻力与冲突</strong><span>品牌可靠性和同价位权益会削弱价格优势，需用售后与金融方案消解。</span></div><div><strong>策略建议</strong><span>主推中配组合，明确真实续航与保障承诺；对家庭用户提供舒适包选装。</span></div></div></div>
        <div className="confidence-grid">
          <div><span>真实标签</span><strong>12项</strong></div>
          <div><span>AI推断</span><strong>3项</strong></div>
          <div><span>更新</span><strong>2026-07-09</strong></div>
        </div>
        <div className="qa-history compact-list">
          <div className="asset-card-head">
            <strong>问答记录</strong>
            <span>{savedSessions.length} 条</span>
          </div>
          {savedSessions.slice(0, 2).map((session) => (
            <div className="history-item" key={session.id}>
              <strong>{session.topic}</strong>
              <span>{session.consumer} · {session.turns} 轮 · {session.savedAt}</span>
            </div>
          ))}
        </div>
      </aside></>}
      </div>
    </div>
  );
}

function TagGroupDetailModal({ group, source, consumerTemplates, onClose }) {
  const matchedTemplates = consumerTemplates.filter((template) => template.linkedTags.some((tag) => group.tags.some((item) => item.name === tag)));

  return (
    <div className="modal-backdrop">
      <section className="maintenance-modal detail-modal">
        <header className="modal-header">
          <div>
            <span>标签维度详情</span>
            <strong>{group.group}</strong>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <div className="detail-body">
          <div className="detail-summary">
            <div><span>上游来源</span><strong>{source}</strong></div>
            <div><span>标签项</span><strong>{group.tags.length} 项</strong></div>
            <div><span>下游模板</span><strong>{matchedTemplates.length || 0} 个</strong></div>
          </div>
          <div className="mini-table">
            {group.tags.map((tag) => (
              <div key={tag.id}>
                <span>{tag.name}</span>
                <strong>{formatNumber(tag.size)}</strong>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

function ConsumerTemplateDetailModal({ template, users, tagRows = [], tasks = [], qaRecords = [], logs = [], onClose, onEdit }) {
  const [activeTab, setActiveTab] = useState('overview');
  const matchedUsers = buildConsumerSamplePreview(template, users);
  const conditionCoverage = buildConsumerConditionCoverage(template, users);
  const usage = buildConsumerUsage(template, tasks, qaRecords);
  const tabs = [
    ['overview', '概览'],
    ['composition', '画像构成'],
    ['samples', '样本验证'],
    ['usage', '使用记录'],
  ];
  const profileCategoryForTag = (tag) => {
    const directMatch = tagRows.find((row) => row.values.includes(tag));
    if (directMatch) return directMatch.category;
    if (/岁|性别|男|女|本科|硕士|城市|国企|企业|职业|退休/.test(tag)) return '个人属性';
    if (/已婚|单身|家庭|孩|老人|同住/.test(tag)) return '家庭属性';
    if (/预算|万|收入|租房|住房|购买力/.test(tag)) return '经济属性';
    if (/通勤|地铁|高铁|自驾|出行|旅行|跨城/.test(tag)) return '出行属性';
    if (/首购|增购|换购|新能源|SUV|车主|电动|驾龄/.test(tag)) return '拥车与购车属性';
    return '偏好属性';
  };
  const profileSections = template.linkedTags.reduce((sections, tag) => {
    const label = profileCategoryForTag(tag);
    const current = sections.find((section) => section.label === label);
    if (current) current.tags.push(tag);
    else sections.push({ label, tags: [tag] });
    return sections;
  }, []);
  const coverageByCondition = new Map(conditionCoverage.map((item) => [item.condition, item]));
  const profileSignals = template.linkedTags.map((tag) => ({
    label: tag,
    ...coverageByCondition.get(tag),
    category: profileSections.find((section) => section.tags.includes(tag))?.label || '画像属性',
  }));
  const radarData = profileSignals.slice(0, 5).map((signal) => ({ label: signal.label, target: signal.rate, baseline: 100 }));
  const averageCoverage = profileSignals.length ? Math.round(profileSignals.reduce((total, signal) => total + signal.rate, 0) / profileSignals.length) : 0;
  const availableUsers = users.filter((user) => user.status === '启用');
  const latestSampleUpdatedAt = matchedUsers[0]?.updatedAt || '暂无命中样本';
  const compositionPanel = <section className="consumer-evidence-panel composition-panel">
    <div className="consumer-panel-heading"><strong>画像构成</strong><span>标签覆盖</span></div>
    <div className="composition-content">
      <div className="consumer-signal-list">{profileSignals.map((signal) => <div className="consumer-signal" key={signal.label}><div><strong>{signal.label}</strong><span>{signal.rate}%</span></div><i><b style={{ width: `${signal.rate}%` }} /></i><em>{signal.count} 位</em></div>)}</div>
      <div className="consumer-radar-wrap"><ResponsiveContainer width="100%" height={154}><RadarChart data={radarData} outerRadius="60%"><PolarGrid stroke="#dbe4f0" /><PolarAngleAxis dataKey="label" tick={{ fill: '#627087', fontSize: 10 }} /><Radar dataKey="baseline" stroke="#b3bfce" strokeDasharray="4 4" fill="none" /><Radar dataKey="target" stroke="#1769e8" fill="#1769e8" fillOpacity={0.1} /></RadarChart></ResponsiveContainer></div>
    </div>
  </section>;
  const conditionPanel = <section className="consumer-evidence-panel condition-panel">
    <div className="consumer-panel-heading"><strong>关键定义条件</strong><button className="secondary small" onClick={onEdit}><Pencil size={13} /> 修改条件</button></div>
    <div className="condition-table"><div className="condition-row condition-head"><span>维度</span><span>条件</span><span>命中用户</span><span>可用用户占比</span></div>{profileSignals.map((signal, index) => <div className="condition-row" key={signal.label}><span><b>{index + 1}</b>{signal.category}</span><strong>{signal.label}</strong><span>{signal.count} 位</span><em>{signal.rate}%</em></div>)}</div>
  </section>;
  const samplePanel = <ConsumerSamplePanel matchedUsers={matchedUsers} />;
  const usageRecords = [...usage.tasks.map((task) => [task.name, '消费调研', task.status, task.updatedAt]), ...usage.qaRecords.map((record) => [record.topic, '模拟问答', '已保存', record.savedAt])];
  const auditRecords = logs.filter((log) => log.menu === '消费者库').slice(0, 5);

  return (
    <div className="modal-backdrop">
      <section className="maintenance-modal detail-modal wide consumer-detail-modal">
        <header className="consumer-detail-header">
          <div className="consumer-detail-title">
            <span>消费者完整画像</span>
            <strong>{template.name}</strong>
            <em>{template.status}</em>
          </div>
          <button className="primary small" onClick={onEdit}><Pencil size={14} /> 编辑画像</button>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <nav className="consumer-detail-tabs" aria-label="消费者详情导航">
          {tabs.map(([id, label]) => <button className={activeTab === id ? 'active' : ''} onClick={() => setActiveTab(id)} key={id}>{label}</button>)}
        </nav>
        <div className="detail-body consumer-detail-workspace">
          <section className="consumer-detail-hero">
            <div className="consumer-detail-identity">
              <div className="persona-avatar"><UsersRound size={31} /></div>
              <div><h2>{template.name}</h2><p>{template.description}</p><div className="chips">{template.linkedTags.map((tag) => <span key={tag}>{tag}</span>)}</div></div>
            </div>
            <DetailMetric icon={UsersRound} label="预计覆盖" value={`${formatNumber(template.users)} 人`} />
            <DetailMetric icon={Target} label="定义条件" value={`${template.linkedTags.length} 项`} />
            <DetailMetric icon={Database} label="命中样本" value={`${matchedUsers.length} 位`} />
            <DetailMetric icon={Check} label="状态" value={template.status} />
          </section>
          {activeTab === 'overview' && <><div className="consumer-overview-grid"><section className="consumer-evidence-panel overview-profile-panel"><div className="consumer-panel-heading"><strong>画像摘要</strong><span>{template.source}</span></div><div className="overview-profile-main"><div className="overview-coverage-number"><strong>{averageCoverage}%</strong><span>条件平均覆盖</span></div><div>{profileSignals.map((signal) => <div className="overview-coverage-line" key={signal.label}><span>{signal.label}</span><i><b style={{ width: `${signal.rate}%` }} /></i><strong>{signal.rate}%</strong></div>)}</div></div><div className="overview-meta"><span>适用范围</span><strong>{template.coverage}</strong><span>最近样本更新</span><strong>{latestSampleUpdatedAt}</strong></div></section>{conditionPanel}</div>{samplePanel}</>}
          {activeTab === 'composition' && <div className="consumer-tab-grid"><section className="consumer-evidence-panel composition-expanded-panel">{compositionPanel}<div className="composition-stat-strip"><div><span>可用用户</span><strong>{availableUsers.length} 位</strong></div><div><span>平均覆盖</span><strong>{averageCoverage}%</strong></div><div><span>定义维度</span><strong>{profileSections.length} 类</strong></div></div></section><section className="consumer-evidence-panel consumer-profile-panel"><div className="consumer-panel-heading"><strong>标签结构</strong><span>来源：标签体系</span></div>{profileSections.map((section) => <div className="consumer-profile-group" key={section.label}><strong>{section.label}</strong><div className="chips">{section.tags.map((tag) => <span key={tag}>{tag}</span>)}</div></div>)}</section></div>}
          {activeTab === 'samples' && <><section className="consumer-validation-strip"><div><span>可用用户总数</span><strong>{availableUsers.length} 位</strong></div><div><span>完整命中</span><strong>{matchedUsers.length} 位</strong></div><div><span>定义条件</span><strong>{template.linkedTags.length} 项</strong></div><div><span>数据来源</span><strong>{template.source}</strong></div></section>{samplePanel}</>}
          {activeTab === 'usage' && <><section className="consumer-usage-strip"><div><span>消费调研</span><strong>{usage.tasks.length}</strong></div><div><span>已完成调研</span><strong>{usage.completedCount}</strong></div><div><span>模拟问答</span><strong>{usage.qaRecords.length}</strong></div><div><span>近期操作</span><strong>{auditRecords.length}</strong></div></section><section className="consumer-evidence-panel usage-panel"><div className="consumer-panel-heading"><strong>关联使用记录</strong></div><div className="usage-table"><div className="usage-row usage-head"><span>名称</span><span>使用模块</span><span>状态</span><span>最近时间</span></div>{usageRecords.length ? usageRecords.map((record) => <div className="usage-row" key={`${record[1]}-${record[0]}`}><strong>{record[0]}</strong><span>{record[1]}</span><span className={`status ${record[2] === '已完成' ? '启用' : '待复核'}`}>{record[2]}</span><span>{record[3]}</span></div>) : <div className="consumer-sample-empty">暂无关联使用记录</div>}</div></section><section className="consumer-evidence-panel usage-panel"><div className="consumer-panel-heading"><strong>消费者库近期操作</strong></div><div className="usage-table"><div className="usage-row usage-head"><span>操作</span><span>操作人</span><span>对象</span><span>时间</span></div>{auditRecords.length ? auditRecords.map((record) => <div className="usage-row" key={record.id}><strong>{record.action}</strong><span>{record.user}</span><span>{record.target}</span><span>{record.time}</span></div>) : <div className="consumer-sample-empty">暂无操作记录</div>}</div></section></>}
        </div>
      </section>
    </div>
  );
}

function DetailMetric({ icon: Icon, label, value }) {
  return <div className="consumer-detail-metric"><Icon size={20} /><span>{label}</span><strong>{value}</strong></div>;
}

function ConsumerSamplePanel({ matchedUsers }) {
  return <section className="consumer-evidence-panel consumer-sample-panel"><div className="consumer-panel-heading"><strong>命中样本</strong><div className="sample-summary"><span><UsersRound size={15} /> {matchedUsers.length} 位</span><span><Check size={15} /> 启用</span></div></div>
    <div className="consumer-sample-table"><div className="consumer-sample-row consumer-sample-head"><span>样本 ID</span><span>姓名</span><span>手机号</span><span>样本标签</span><span>命中条件</span><span>匹配数</span><span>状态</span><span>更新时间</span></div>{matchedUsers.length ? matchedUsers.slice(0, 8).map((user) => <div className="consumer-sample-row" key={user.id}><strong>{user.id}</strong><span>{user.name}</span><span>{user.phone}</span><div className="table-tags">{user.tags.map((tag) => <span key={tag}>{tag}</span>)}</div><div className="condition-match-list">{user.matchedTags.map((tag) => <span key={tag}>{tag}</span>)}</div><b>{user.matchedTags.length} / {user.matchedTags.length}</b><span className={`status ${user.status}`}>{user.status}</span><span>{user.updatedAt}</span></div>) : <div className="consumer-sample-empty">当前模板没有满足全部条件的可用样本</div>}</div>
  </section>;
}

function ScenarioTemplateDetailModal({ template, consumerTemplates, onClose }) {
  return (
    <div className="modal-backdrop">
      <section className="maintenance-modal detail-modal">
        <header className="modal-header">
          <div>
            <span>调研场景详情</span>
            <strong>{template.name}</strong>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <div className="detail-body">
          <div className="portrait-grid">
            <div><span>输入结构</span><strong>{template.input}</strong></div>
            <div><span>输出口径</span><strong>{template.outputs}</strong></div>
            <div><span>业务阶段</span><strong>{template.stage}</strong></div>
            <div><span>状态</span><strong>{template.status}</strong></div>
          </div>
          <div className="detail-question">
            <span>默认问题</span>
            <strong>{template.question}</strong>
          </div>
          <section className="scenario-dimension-summary"><div><strong>报告分析维度</strong><span>完成调研后将按以下维度生成对比、归因和建议。</span></div><div className="chips">{(template.analysisDimensions || analysisDimensionOptions.slice(0, 4)).map((dimension) => <span key={dimension}>{dimension}</span>)}</div></section>
          <div className="chips">
            {consumerTemplates.filter((item) => item.status === '启用').slice(0, 3).map((item) => <span key={item.id}>{item.name}</span>)}
          </div>
        </div>
      </section>
    </div>
  );
}

function QaHistoryPage({ records }) {
  const [query, setQuery] = useState('');
  const filteredRecords = records.filter((record) => {
    const keyword = query.trim();
    if (!keyword) return true;
    return [record.id, record.consumer, record.topic, record.question, record.owner].some((value) => value.includes(keyword));
  });

  return (
    <div className="asset-page">
      <PageIntro
        title="历史问答记录列表"
        description="沉淀模拟问答过程，可按消费者模板、问题主题和保存人追溯。"
      />
      <div className="list-filter-row">
        <div className="search-field">
          <Search size={16} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索记录ID、主题、消费者或保存人" />
        </div>
        <button className="secondary"><Filter size={15} /> 自定义筛选</button>
      </div>
      <div className="qa-history-table">
        <div className="qa-history-row table-head">
          <span>记录ID</span>
          <span>主题</span>
          <span>消费者模板</span>
          <span>问题摘要</span>
          <span>轮次</span>
          <span>保存人</span>
          <span>保存时间</span>
          <span>操作</span>
        </div>
        {filteredRecords.map((record) => (
          <div className="qa-history-row" key={record.id}>
            <strong>{record.id}</strong>
            <span>{record.topic}</span>
            <span>{record.consumer}</span>
            <span>{record.question}</span>
            <span>{record.turns}</span>
            <span>{record.owner}</span>
            <span>{record.savedAt}</span>
            <div className="row-action-buttons">
              <button className="text-button">查看</button>
              <button className="text-button">复用</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SystemSettingsModal({ activePage, setActivePage, accounts, setAccounts, roles, setRoles, logs, appendLog, onClose }) {
  const settingItems = [
    { page: 'accounts', label: '账号管理', icon: UserRound },
    { page: 'roles', label: '角色管理', icon: BookOpenCheck },
    { page: 'logs', label: '操作日志', icon: Activity }
  ];

  return (
    <div className="modal-backdrop">
      <section className="settings-modal">
        <header className="modal-header">
          <div>
            <strong>系统设置</strong>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭系统设置"><X size={18} /></button>
        </header>
        <div className="settings-modal-body">
          <aside className="settings-modal-nav">
            {settingItems.map(({ page, label, icon: Icon }) => (
              <button className={activePage === page ? 'active' : ''} onClick={() => setActivePage(page)} key={page}>
                <Icon size={17} />
                {label}
              </button>
            ))}
          </aside>
          <div className="settings-modal-content">
            <SystemSettingsPage
              activePage={activePage}
              accounts={accounts}
              setAccounts={setAccounts}
              roles={roles}
              setRoles={setRoles}
              logs={logs}
              appendLog={appendLog}
            />
          </div>
        </div>
      </section>
    </div>
  );
}

function SystemSettingsPage({ activePage, accounts, setAccounts, roles, setRoles, logs, appendLog }) {
  if (activePage === 'roles') {
    return <RoleManagementPage roles={roles} setRoles={setRoles} appendLog={appendLog} />;
  }

  if (activePage === 'logs') {
    return <OperationLogPage logs={logs} />;
  }

  return <AccountManagementPage accounts={accounts} setAccounts={setAccounts} roles={roles} appendLog={appendLog} />;
}

function AccountManagementPage({ accounts, setAccounts, roles, appendLog }) {
  const [builderOpen, setBuilderOpen] = useState(false);
  const columns = ['ID', '用户名', '角色', '状态', '最近登录', '操作'];

  function saveAccount(form) {
    const newAccount = {
      name: form.name,
      id: `U-${String(accounts.length + 1).padStart(4, '0')}`,
      role: form.role,
      team: form.team,
      status: '启用',
      lastLogin: '尚未登录'
    };
    setAccounts((current) => [newAccount, ...current]);
    appendLog('新增账号', newAccount.name);
    setBuilderOpen(false);
  }

  function toggleAccount(name) {
    setAccounts((current) => current.map((account) => (
      account.name === name
        ? { ...account, status: account.status === '启用' ? '停用' : '启用' }
        : account
    )));
    appendLog('调整账号状态', name);
  }

  return (
    <div className="asset-page">
      <PageIntro
        title="账号管理"
        description="维护平台用户、角色归属和账号启停状态。"
        action="新增账号"
        onAction={() => setBuilderOpen(true)}
      />
      <div className="settings-table">
        <div className="settings-row table-head" style={{ gridTemplateColumns: `repeat(${columns.length}, minmax(110px, 1fr))` }}>
          {columns.map((column) => <span key={column}>{column}</span>)}
        </div>
        {accounts.map((account) => (
          <div className="settings-row" style={{ gridTemplateColumns: `repeat(${columns.length}, minmax(110px, 1fr))` }} key={account.name}>
            <span>{account.id}</span>
            <span>{account.name}</span>
            <span>{account.role}</span>
            <span className={`status ${account.status}`}>{account.status}</span>
            <span>{account.lastLogin}</span>
            <div className="row-action-buttons"><button className="text-button setting-action">编辑</button><button className="text-button setting-action" onClick={() => toggleAccount(account.name)}>{account.status === '启用' ? '停用' : '启用'}</button></div>
          </div>
        ))}
      </div>
      {builderOpen && <AccountBuilder roles={roles} onClose={() => setBuilderOpen(false)} onSave={saveAccount} />}
    </div>
  );
}

function RoleManagementPage({ roles, setRoles, appendLog }) {
  const [builderOpen, setBuilderOpen] = useState(false);
  const columns = ['角色名称', '权限范围', '成员数', '状态', '操作'];

  function saveRole(form) {
    const newRole = {
      name: form.name,
      scope: form.modules.join('、'),
      members: 0,
      status: '启用',
      modules: form.modules
    };
    setRoles((current) => [newRole, ...current]);
    appendLog('新增角色', newRole.name);
    setBuilderOpen(false);
  }

  function deleteRole(role) {
    if (role.status === '启用') return;
    setRoles((current) => current.filter((item) => item.name !== role.name));
    appendLog('删除角色', role.name);
  }

  return (
    <div className="asset-page">
      <PageIntro
        title="角色管理"
        description="控制不同角色可访问的数据资产、调研任务和系统设置范围。"
        action="新增角色"
        onAction={() => setBuilderOpen(true)}
      />
      <div className="settings-table">
        <div className="settings-row table-head" style={{ gridTemplateColumns: `repeat(${columns.length}, minmax(130px, 1fr))` }}>
          {columns.map((column) => <span key={column}>{column}</span>)}
        </div>
        {roles.map((role) => (
          <div className="settings-row" style={{ gridTemplateColumns: `repeat(${columns.length}, minmax(130px, 1fr))` }} key={role.name}>
            <span>{role.name}</span>
            <span>{role.scope}</span>
            <span>{role.members}</span>
            <span className={`status ${role.status}`}>{role.status}</span>
            <div className="row-action-buttons"><button className="text-button">编辑</button><button className="text-button danger-text" disabled={role.status === '启用'} onClick={() => deleteRole(role)}>删除</button></div>
          </div>
        ))}
      </div>
      {builderOpen && <RoleBuilder onClose={() => setBuilderOpen(false)} onSave={saveRole} />}
    </div>
  );
}

function PermissionMatrix({ roles }) {
  const modules = ['标签体系', '用户数据', '消费者库', '调研场景', '消费调研', '模拟问答', '系统设置'];

  return (
    <section className="permission-matrix">
      <div className="asset-card-head">
        <strong>权限矩阵</strong>
        <span>模块级授权</span>
      </div>
      <div className="matrix-grid">
        <span />
        {modules.map((module) => <strong key={module}>{module}</strong>)}
        {roles.map((role) => (
          <React.Fragment key={role.name}>
            <strong>{role.name}</strong>
            {modules.map((module) => <span className={role.modules.includes(module) ? 'allowed' : ''} key={`${role.name}-${module}`}>{role.modules.includes(module) ? '可用' : '-'}</span>)}
          </React.Fragment>
        ))}
      </div>
    </section>
  );
}

function OperationLogPage({ logs }) {
  const rows = logs.map((log) => [log.id, log.user, log.menu, log.action, log.time, log.ip]);

  return (
    <div className="asset-page">
      <SettingsTable
        title="操作日志"
        description="记录用户在各菜单中的关键操作与来源地址。"
        columns={['ID', '用户', '菜单', '操作', '时间', 'IP']}
        rows={rows}
      />
    </div>
  );
}

function AccountBuilder({ roles, onClose, onSave }) {
  return (
    <div className="modal-backdrop">
      <section className="maintenance-modal">
        <header className="modal-header">
          <div>
            <span>账号管理</span>
            <strong>新增账号</strong>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <div className="maintenance-body">
          <label>
            姓名
            <input id="account-name" defaultValue="刘妍" />
          </label>
          <label>
            角色
            <select id="account-role" defaultValue={roles[1]?.name || roles[0]?.name}>
              {roles.map((role) => <option key={role.name}>{role.name}</option>)}
            </select>
          </label>
          <label>
            团队
            <input id="account-team" defaultValue="用户研究组" />
          </label>
          <div className="maintenance-checks">
            <div><Check size={15} /> 已匹配角色权限</div>
            <div><Check size={15} /> 首次登录需绑定企业账号</div>
          </div>
        </div>
        <footer className="modal-footer">
          <button className="secondary" onClick={onClose}>取消</button>
          <button
            className="primary"
            onClick={() => onSave({
              name: document.getElementById('account-name').value || '新账号',
              role: document.getElementById('account-role').value,
              team: document.getElementById('account-team').value || '未分组'
            })}
          >
            保存账号
          </button>
        </footer>
      </section>
    </div>
  );
}

function RoleBuilder({ onClose, onSave }) {
  const modules = ['标签体系', '用户数据', '消费者库', '调研场景', '消费调研', '模拟问答', '系统设置'];

  return (
    <div className="modal-backdrop">
      <section className="maintenance-modal">
        <header className="modal-header">
          <div>
            <span>角色管理</span>
            <strong>新增角色</strong>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <div className="maintenance-body">
          <label>
            角色名称
            <input id="role-name" defaultValue="研究负责人" />
          </label>
          <div className="builder-tags">
            {modules.map((module, index) => (
              <label key={module}>
                <input type="checkbox" defaultChecked={index >= 2 && index <= 5} value={module} />
                {module}
              </label>
            ))}
          </div>
          <div className="maintenance-checks">
            <div><Check size={15} /> 权限矩阵将实时更新</div>
            <div><Check size={15} /> 操作会写入审计日志</div>
          </div>
        </div>
        <footer className="modal-footer">
          <button className="secondary" onClick={onClose}>取消</button>
          <button
            className="primary"
            onClick={() => onSave({
              name: document.getElementById('role-name').value || '新角色',
              modules: Array.from(document.querySelectorAll('.builder-tags input:checked')).map((input) => input.value)
            })}
          >
            保存角色
          </button>
        </footer>
      </section>
    </div>
  );
}

function SettingsTable({ title, description, columns, rows }) {
  return (
    <>
      <PageIntro title={title} description={description} />
      <div className="settings-table">
        <div className="settings-row table-head" style={{ gridTemplateColumns: `repeat(${columns.length}, minmax(120px, 1fr))` }}>
          {columns.map((column) => <span key={column}>{column}</span>)}
        </div>
        {rows.map((row, index) => (
          <div className="settings-row" style={{ gridTemplateColumns: `repeat(${columns.length}, minmax(120px, 1fr))` }} key={index}>
            {row.map((cell) => <span key={cell}>{cell}</span>)}
          </div>
        ))}
      </div>
    </>
  );
}

function PageIntro({ title, action, onAction, filters, actions }) {
  return (
    <div className="page-header">
      <h2>{title}</h2>
      <div className="header-tools">
        {filters}
        <div className="toolbar-actions">
          {actions}
          {action && <button className="primary" onClick={onAction}><Plus size={16} /> {action}</button>}
        </div>
      </div>
    </div>
  );
}

function HeaderFilterSelect({ children, ...props }) {
  return <div className="header-filter-select"><Filter size={14} /><select {...props}>{children}</select></div>;
}

function Pagination({ total, page, pageCount, onPageChange }) {
  const pages = Array.from({ length: pageCount }, (_, index) => index + 1);
  const pageItems = pageCount <= 7
    ? pages
    : [
        1,
        ...(page > 3 ? ['left-gap'] : []),
        ...pages.filter((item) => item > 1 && item < pageCount && Math.abs(item - page) <= 1),
        ...(page < pageCount - 2 ? ['right-gap'] : []),
        pageCount
      ];

  return (
    <div className="pagination">
      <span>共 {total} 条，每页 20 条</span>
      <div>
        <button className="secondary small" onClick={() => onPageChange(Math.max(1, page - 1))} disabled={page === 1}>上一页</button>
        {pageItems.map((item) => typeof item === 'number'
          ? <button className={page === item ? 'page-number active' : 'page-number'} onClick={() => onPageChange(item)} key={item}>{item}</button>
          : <span className="pagination-gap" key={item}>…</span>)}
        <button className="secondary small" onClick={() => onPageChange(Math.min(pageCount, page + 1))} disabled={page === pageCount}>下一页</button>
      </div>
    </div>
  );
}

function TagEditorModal({ tag, categories, onClose, onSave }) {
  const [contentItems, setContentItems] = useState((tag.contentItems || tag.values || []).map((item) => typeof item === 'string' ? { value: item, status: '启用' } : item));

  return (
    <div className="modal-backdrop">
      <section className="maintenance-modal wide-editor">
        <header className="modal-header">
          <div><strong>{tag.id ? '编辑标签' : '新增标签'}</strong></div>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <div className="maintenance-body editor-grid">
          <label>标签名称<input id="tag-name" defaultValue={tag.name} /></label>
          <label>一级分类<select id="tag-category" defaultValue={tag.category}>{categories.map((category) => <option key={category}>{category}</option>)}</select></label>
          <label className="span-all">标签定义<textarea id="tag-definition" defaultValue={tag.definition || ''} /></label>
          <label className="span-all">同义词<textarea id="tag-synonyms" defaultValue={tag.synonyms || ''} placeholder="多个同义词以顿号或逗号分隔" /></label>
          <label className="span-all">标签内容
            <div className="tag-content-editor">
              <div className="tag-content-table">
                <div className="tag-content-table-head"><span>内容选项</span><span>内容状态</span><span>操作</span></div>
                {contentItems.map((item) => <div className="tag-content-table-row" key={item.value}>
                  <span>{item.value}</span>
                  <span className={`status ${item.status}`}>{item.status}</span>
                  <div><button type="button" className="text-button" onClick={() => setContentItems((current) => current.map((entry) => entry.value === item.value ? { ...entry, status: entry.status === '启用' ? '停用' : '启用' } : entry))}>{item.status === '启用' ? '禁用' : '启用'}</button><button type="button" className="text-button danger" onClick={() => setContentItems((current) => current.filter((entry) => entry.value !== item.value))}>删除</button></div>
                </div>)}
              </div>
            </div>
          </label>
          <label>标签状态<select id="tag-status" defaultValue={tag.status || '启用'}><option>启用</option><option>停用</option></select></label>
        </div>
        <footer className="modal-footer"><button className="secondary" onClick={onClose}>取消</button><button className="primary" onClick={() => onSave({ ...tag, category: document.getElementById('tag-category').value, name: document.getElementById('tag-name').value || '未命名标签', definition: document.getElementById('tag-definition').value, synonyms: document.getElementById('tag-synonyms').value, values: contentItems.map((item) => item.value), contentItems, content: contentItems.map((item) => item.value).join('、'), status: document.getElementById('tag-status').value })}>确定</button></footer>
      </section>
    </div>
  );
}

function TagGroupBuilder({ onClose, onSave }) {
  return (
    <div className="modal-backdrop">
      <section className="maintenance-modal">
        <header className="modal-header">
          <div>
            <span>标签体系</span>
            <strong>新增标签维度</strong>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <div className="maintenance-body">
          <label>
            维度名称
            <input id="tag-group-name" defaultValue="生活方式" />
          </label>
          <label>
            标签项
            <textarea id="tag-group-tags" defaultValue="城市露营,亲子出行,智能家居,周末短途游" />
          </label>
          <div className="maintenance-checks">
            <div><Check size={15} /> 已关联用户数据来源</div>
            <div><Check size={15} /> 可被消费者模板调用</div>
          </div>
        </div>
        <footer className="modal-footer">
          <button className="secondary" onClick={onClose}>取消</button>
          <button
            className="primary"
            onClick={() => onSave({
              group: document.getElementById('tag-group-name').value || '新标签维度',
              tags: document.getElementById('tag-group-tags').value
                .split(/[，,\n]/)
                .map((tag) => tag.trim())
                .filter(Boolean)
            })}
          >
            保存维度
          </button>
        </footer>
      </section>
    </div>
  );
}

function UserBuilder({ user, tagRows, onClose, onSave }) {
  const [selectedTags, setSelectedTags] = useState(user.tags || []);
  const categories = Array.from(new Set(tagRows.map((row) => row.category)));
  const editorPages = ['基本信息', ...categories, '预测属性'];
  const [activePageIndex, setActivePageIndex] = useState(0);
  const [form, setForm] = useState({ phone: user.phone || '138****0000', name: user.name || '新用户', status: user.status || '启用' });
  const [predictedTags, setPredictedTags] = useState([]);
  const [selectedPredictedTags, setSelectedPredictedTags] = useState([]);
  const [isPredicting, setIsPredicting] = useState(false);
  const [predictionRound, setPredictionRound] = useState(0);
  const isEditing = Boolean(user.id);
  const activePage = editorPages[activePageIndex];
  const activeCategory = categories.includes(activePage) ? activePage : null;
  const activeCategoryTags = tagRows.filter((row) => row.category === activeCategory);

  function selectPage(index) {
    setActivePageIndex(index);
  }

  function toggleTag(tag) {
    setSelectedTags((current) => (current.includes(tag) ? current.filter((item) => item !== tag) : [...current, tag]));
  }

  function generatePredictedTags() {
    const predictionSets = [
      [
        { name: '纯电SUV意向客', category: '车型偏好预测', confidence: 92, reason: '基于城市通勤场景与产品关注信号，推断为纯电 SUV 的高相关潜客' },
        { name: '城市补能便利性关注', category: '用车顾虑预测', confidence: 88, reason: '对居住地充电条件、补能效率和周边公共充电覆盖更敏感' },
        { name: '续航达成率敏感', category: '产品卖点预测', confidence: 84, reason: '更关注真实续航、季节衰减与高速工况下的续航可信度' },
        { name: '智能座舱体验驱动', category: '配置偏好预测', confidence: 76, reason: '座舱交互、语音能力与生态连接会显著影响其体验评价' }
      ],
      [
        { name: '试驾转化潜力客', category: '购车阶段预测', confidence: 90, reason: '具备从线上了解转向到店体验与深度比较的行为条件' },
        { name: '竞品横评决策型', category: '决策路径预测', confidence: 82, reason: '倾向围绕价格、续航与核心配置建立同级车型对比清单' },
        { name: '购车金融权益敏感', category: '价格策略预测', confidence: 79, reason: '低月供、置换补贴和限时权益会明显影响最终决策节奏' },
        { name: '售后确定性关注', category: '服务偏好预测', confidence: 73, reason: '交付周期、网点覆盖与三电保障是降低购买顾虑的关键因素' }
      ]
    ];
    const nextTags = predictionSets[predictionRound % predictionSets.length];
    setIsPredicting(true);
    window.setTimeout(() => {
      setPredictedTags(nextTags);
      setSelectedPredictedTags(nextTags.map((tag) => tag.name));
      setPredictionRound((current) => current + 1);
      setIsPredicting(false);
    }, 420);
  }

  function togglePredictedTag(tag) {
    setSelectedPredictedTags((current) => current.includes(tag) ? current.filter((item) => item !== tag) : [...current, tag]);
  }

  return (
    <div className="modal-backdrop">
      <section className="maintenance-modal wide-editor user-editor">
        <header className="modal-header">
          <div>
            <strong>{isEditing ? '编辑用户' : '新增用户'}</strong>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <div className="maintenance-body user-editor-body">
          <div className="user-page-heading"><span>用户信息维护</span><strong>{activePage}</strong></div>
          <div className="user-editor-pages" role="tablist" aria-label="用户编辑分页">{editorPages.map((page, index) => <button type="button" role="tab" aria-selected={index === activePageIndex} className={index === activePageIndex ? 'active' : ''} key={page} onClick={() => selectPage(index)}>{page}</button>)}</div>
          {activePage === '基本信息' && <div className="user-basic-fields">
            {isEditing && (
            <label>
              用户ID
              <input id="user-id" defaultValue={user.id} disabled />
            </label>
          )}
            <label>
              手机号
              <input value={form.phone} onChange={(event) => setForm((current) => ({ ...current, phone: event.target.value }))} />
          </label>
          <label>
              姓名
              <input value={form.name} onChange={(event) => setForm((current) => ({ ...current, name: event.target.value }))} />
          </label>
          <label>
              用户状态
              <select value={form.status} onChange={(event) => setForm((current) => ({ ...current, status: event.target.value }))}>
              <option>启用</option>
              <option>停用</option>
            </select>
          </label>
          </div>}
          {activeCategory && <div className="taxonomy-editor fixed-taxonomy-editor"><section className="taxonomy-selector">{activeCategoryTags.map((row) => <div className="taxonomy-option" key={row.id}><span>{row.name}</span><div>{row.values.map((value) => <label key={value}><input type="checkbox" checked={selectedTags.includes(value)} onChange={() => toggleTag(value)} />{value}</label>)}</div></div>)}</section></div>}
          {activePage === '预测属性' && <section className="user-prediction-panel" aria-label="AI标签预测">
            {!predictedTags.length && !isPredicting && <div className="prediction-empty"><Database size={22} /><strong>生成汽车调研预测标签</strong><span>基于用户资料生成车型偏好、购车阶段、产品卖点和服务顾虑等专属标签。</span><button type="button" className="primary" onClick={generatePredictedTags}>生成标签</button></div>}
            {isPredicting && <div className="prediction-empty"><RefreshCw className="spin" size={22} /><strong>正在分析用户特征</strong><span>将综合基础信息与当前已选标签生成建议。</span></div>}
            {!!predictedTags.length && !isPredicting && <><div className="prediction-head"><div><strong>AI 汽车调研标签预测</strong><span>以下为独立预测标签，不复用现有用户标签体系。</span></div><button type="button" className="secondary small" onClick={generatePredictedTags}>重新生成</button></div><div className="prediction-summary"><span>已生成 {predictedTags.length} 个候选标签</span><button type="button" className="text-button" onClick={() => setSelectedPredictedTags(predictedTags.map((tag) => tag.name))}>全选</button><button type="button" className="text-button" onClick={() => setSelectedPredictedTags([])}>清空选择</button></div><div className="prediction-tag-list">{predictedTags.map((tag) => <label className={selectedPredictedTags.includes(tag.name) ? 'selected' : ''} key={tag.name}><input type="checkbox" checked={selectedPredictedTags.includes(tag.name)} onChange={() => togglePredictedTag(tag.name)} /><div><strong>{tag.name}</strong><span>{tag.category} · 置信度 {tag.confidence}%</span><small>{tag.reason}</small></div></label>)}</div></>}
          </section>}
          {!activeCategory && activePage !== '基本信息' && activePage !== '预测属性' && <div className="user-empty-page"><Database size={20} /><strong>{activePage}</strong><span>该页预留给后续数据接入与维护。</span></div>}
        </div>
        <footer className="modal-footer">
          <button className="secondary" onClick={onClose}>取消</button>
          <button
            className="primary"
            onClick={() => onSave({
              id: user.id,
              phone: form.phone || '138****0000',
              name: form.name || '新用户',
              tags: Array.from(new Set([...selectedTags, ...selectedPredictedTags])),
              creator: user.creator || '张明',
              status: form.status,
              source: user.source || '手动新增'
            })}
          >
            确定
          </button>
        </footer>
      </section>
    </div>
  );
}

function ConsumerTemplateBuilder({ template, tagGroups: groups = tagGroups, userDataAssets = [], onClose, onSave }) {
  const defaultTags = template?.linkedTags || ['25-35岁', '新能源车偏好', '预算15-25万'];
  const [selectedTags, setSelectedTags] = useState(defaultTags);
  const [matchedUsers, setMatchedUsers] = useState(null);
  const [sampleSize, setSampleSize] = useState(template?.sample || '');
  const canConfirm = matchedUsers !== null && matchedUsers > 0 && Number(sampleSize) > 0 && Number(sampleSize) <= matchedUsers;

  function toggleTag(tagName) {
    setSelectedTags((current) => current.includes(tagName) ? current.filter((tag) => tag !== tagName) : [...current, tagName]);
    setMatchedUsers(null);
    setSampleSize('');
  }

  function calculateMatchedUsers() {
    const matchedCount = buildConsumerSamplePreview({ linkedTags: selectedTags }, userDataAssets).length;
    setMatchedUsers(matchedCount);
    if (matchedCount === 0) setSampleSize('');
  }

  return (
    <div className="modal-backdrop">
      <section className="maintenance-modal">
        <header className="modal-header">
          <div>
            <span>消费者库</span>
            <strong>{template ? '编辑消费者模板' : '新建消费者模板'}</strong>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <div className="maintenance-body">
          <label>
            模板名称
            <input id="consumer-template-name" defaultValue={template?.name || '都市新能源主力潜客'} />
          </label>
          <div className="builder-tags grouped-builder-tags">{groups.map((group) => <section key={group.group}><strong>{group.group}</strong>{group.tags.map((tag) => <label key={tag.id}><input type="checkbox" checked={selectedTags.includes(tag.name)} onChange={() => toggleTag(tag.name)} value={tag.name} />{tag.name}<small>{formatNumber(tag.size)} 人</small></label>)}</section>)}</div>
          <div className="consumer-form-metrics"><label>命中用户<div className="consumer-match-input"><input value={matchedUsers === null ? '尚未计算' : `${formatNumber(matchedUsers)} 人`} disabled /><button type="button" className="consumer-match-button" onClick={calculateMatchedUsers}>计算命中用户</button></div></label><label>样本数量<input id="consumer-template-sample" type="number" min="1" max={matchedUsers || undefined} value={sampleSize} disabled={matchedUsers === null || matchedUsers === 0} onChange={(event) => setSampleSize(event.target.value)} placeholder="请输入样本数量" /></label></div>
          <label>
            模板说明
            <textarea id="consumer-template-description" defaultValue={template?.description || '用于新能源 SUV 的主力潜客模拟，可覆盖造型验证、购买意愿和价格敏感度测试。'} />
          </label>
        </div>
        <footer className="modal-footer">
          <button className="secondary" onClick={onClose}>取消</button>
          <button
            className="primary"
            onClick={() => onSave({
              id: template?.id,
              name: document.getElementById('consumer-template-name').value || '新消费者模板',
              source: '统一用户数据源',
              linkedTags: selectedTags,
              users: matchedUsers,
              sample: Number(sampleSize),
              coverage: '造型验证 / 购买意愿 / 模拟问答',
              description: document.getElementById('consumer-template-description').value || '用于消费调研和模拟问答。'
            })}
            disabled={!canConfirm}
          >
            确定
          </button>
        </footer>
      </section>
    </div>
  );
}

function ScenarioTemplateBuilder({ template, onClose, onSave }) {
  const defaultDimensions = template?.analysisDimensions || analysisDimensionOptions.slice(0, 4);
  return (
    <div className="modal-backdrop">
      <section className="maintenance-modal">
        <header className="modal-header">
          <div>
            <span>调研场景</span>
            <strong>{template ? '编辑场景模板' : '新建场景模板'}</strong>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <div className="maintenance-body">
          <label>
            场景名称
            <input id="scenario-template-name" defaultValue={template?.name || '卖点传播话术验证'} />
          </label>
          <label>
            业务阶段
            <select id="scenario-template-stage" defaultValue={template?.stage || '新车上市阶段'}>
              <option>产品设计阶段</option>
              <option>产品定义阶段</option>
              <option>新车上市阶段</option>
            </select>
          </label>
          <label>
            输入结构
            <input id="scenario-template-input" defaultValue={template?.input || '车型卖点与传播话术'} />
          </label>
          <label>
            默认问题
            <textarea id="scenario-template-question" defaultValue={template?.question || '这些卖点是否能让你产生进一步了解或试驾兴趣？哪些表达最有说服力？'} />
          </label>
          <fieldset className="analysis-dimension-builder"><legend>报告分析维度</legend><p>勾选后，该场景生成的调研报告将展示对应的人群差异与归因结果。</p><div>{analysisDimensionOptions.map((dimension) => <label key={dimension}><input type="checkbox" value={dimension} defaultChecked={defaultDimensions.includes(dimension)} />{dimension}</label>)}</div></fieldset>
        </div>
        <footer className="modal-footer">
          <button className="secondary" onClick={onClose}>取消</button>
          <button
            className="primary"
            onClick={() => onSave({
              id: template?.id,
              scenarioId: template?.scenarioId || 'purchase',
              name: document.getElementById('scenario-template-name').value || '新场景模板',
              stage: document.getElementById('scenario-template-stage').value,
              input: document.getElementById('scenario-template-input').value || '结构化输入',
              question: document.getElementById('scenario-template-question').value || '默认调研问题',
              outputs: template?.outputs || '卖点吸引力 / 传播阻力 / 原声归因 / 话术建议',
              analysisDimensions: Array.from(document.querySelectorAll('.analysis-dimension-builder input:checked')).map((input) => input.value),
              status: template?.status || '启用'
            })}
          >
            保存模板
          </button>
        </footer>
      </section>
    </div>
  );
}

function DependencyPanel({ title, rows }) {
  return (
    <section className="dependency-panel">
      <div className="asset-card-head">
        <strong>{title}</strong>
        <span>链路自检</span>
      </div>
      <div className="dependency-list">
        {rows.map(([label, value]) => (
          <div key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </div>
        ))}
      </div>
    </section>
  );
}

function MetricTile({ label, value }) {
  return (
    <div className="metric-tile">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function CreateResearchModal(props) {
  const [consumerMode, setConsumerMode] = useState('template');
  const [scenarioMode, setScenarioMode] = useState('template');
  const [selectedScenarioIds, setSelectedScenarioIds] = useState([props.activeScenario]);
  const [samplePlan, setSamplePlan] = useState({ [props.selectedConsumerTemplateIds[0]]: props.sampleSize });
  const [questions, setQuestions] = useState([{ type: '单选题', title: '您最关注该车型的哪项价值？', options: ['外观造型', '智能配置', '续航补能'] }]);
  const selectedConsumer = props.consumerTemplates.find((item) => props.selectedConsumerTemplateIds.includes(item.id));
  const toggleConsumer = (id) => props.setSelectedConsumerTemplateIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  const toggleScenario = (id) => setSelectedScenarioIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  return (
    <div className="modal-backdrop">
      <section className="research-modal">
        <header className="modal-header">
          <div>
            <strong>新建调研</strong>
          </div>
          <button className="icon-button" onClick={props.onClose} aria-label="关闭"><X size={18} /></button>
        </header>
        <div className="modal-body">
          <div className="builder modal-builder">
            <div className="research-config-grid">
              <main className="research-config-main">
                <section className="research-config-section info-section"><h2><i>1.</i> 基本信息</h2><div className="basic-info-grid"><label className="research-field"><span>调研任务名称 <em>*</em></span><input value={props.taskName} onChange={(event) => props.setTaskName(event.target.value)} placeholder="请输入调研任务名称，便于识别和管理" maxLength="80" /></label><label className="research-field"><span>调研任务描述</span><textarea value={props.taskDescription} onChange={(event) => props.setTaskDescription(event.target.value)} placeholder="请简要描述本次调研目的、主要内容与预期产出（选填）" maxLength="200" /></label></div></section>
                <section className="research-config-section"><div className="config-section-title"><h2>圈选消费者</h2><span>已选 {props.selectedConsumerTemplateIds.length} 个</span></div><nav className="research-choice-tabs">{[['template','消费者模板'],['custom','自定义目标群体'],['ai','AI 自动圈选消费者群体']].map(([id,label]) => <button className={consumerMode === id ? 'active' : ''} onClick={() => setConsumerMode(id)} key={id}>{label}</button>)}</nav>{consumerMode === 'template' ? <><div className="research-template-cards">{props.consumerTemplates.slice(0,9).map((template) => <article className={props.selectedConsumerTemplateIds.includes(template.id) ? 'selected' : ''} key={template.id}><label><input type="checkbox" checked={props.selectedConsumerTemplateIds.includes(template.id)} onChange={() => toggleConsumer(template.id)} /><strong>{template.name}</strong></label><small>{template.coverage}</small><span>{formatNumber(template.users)} 人</span></article>)}</div><div className="selected-sample-table"><strong>已选消费者与样本分配</strong>{props.consumerTemplates.filter((template) => props.selectedConsumerTemplateIds.includes(template.id)).map((template) => <label key={template.id}><span>{template.name}<small>覆盖 {formatNumber(template.users)} 人</small></span><b>样本量</b><input type="number" min="1" value={samplePlan[template.id] || ''} onChange={(event) => setSamplePlan((current) => ({ ...current, [template.id]: Number(event.target.value) }))} /></label>)}</div></> : consumerMode === 'custom' ? <div className="builder-tags grouped-builder-tags">{props.tagGroups.map((group) => <section key={group.group}><strong>{group.group}</strong>{group.tags.map((tag) => <label key={tag.id}><input type="checkbox" checked={props.selectedTags.includes(tag.id)} onChange={() => props.toggleTag(tag.id)} />{tag.name}<small>{formatNumber(tag.size)} 人</small></label>)}</section>)}</div> : <div className="research-empty-config">系统将根据任务描述与场景自动推荐目标消费者群体。</div>}</section>
                <section className="research-config-section"><div className="config-section-title"><h2>设定调研场景</h2><span>已选 {selectedScenarioIds.length} 个</span></div><nav className="research-choice-tabs">{[['template','场景模板'],['custom','自定义场景问题']].map(([id,label]) => <button className={scenarioMode === id ? 'active' : ''} onClick={() => setScenarioMode(id)} key={id}>{label}</button>)}</nav>{scenarioMode === 'template' ? <div className="scenario-table"><div className="scenario-table-head"><span></span><span>场景名称</span><span>场景简介</span><span>预计题量</span></div>{props.scenarioTemplates.slice(0,6).map((template) => <label className={selectedScenarioIds.includes(template.scenarioId) ? 'selected' : ''} key={template.id}><input type="checkbox" checked={selectedScenarioIds.includes(template.scenarioId)} onChange={() => { toggleScenario(template.scenarioId); props.setActiveScenario(template.scenarioId); }} /><strong>{template.name}</strong><small>{scenarios.find((item) => item.id === template.scenarioId)?.summary}</small><b>8–12 题</b></label>)}</div> : <div className="question-builder">{questions.map((question, index) => <article key={index}><header><b>问题 {index + 1}</b><select value={question.type} onChange={(event) => setQuestions((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, type: event.target.value } : item))}><option>单选题</option><option>多选题</option><option>开放性题目</option></select><button onClick={() => setQuestions((current) => current.filter((_, itemIndex) => itemIndex !== index))}>删除</button></header><input value={question.title} placeholder="请输入问题标题" onChange={(event) => setQuestions((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, title: event.target.value } : item))} />{question.type !== '开放性题目' ? <div className="question-options">{question.options.map((option, optionIndex) => <label key={optionIndex}><span>{optionIndex + 1}</span><input value={option} onChange={(event) => setQuestions((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, options: item.options.map((value, valueIndex) => valueIndex === optionIndex ? event.target.value : value) } : item))} /><button onClick={() => setQuestions((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, options: item.options.filter((_, valueIndex) => valueIndex !== optionIndex) } : item))}>删除</button></label>)}<button className="text-button" onClick={() => setQuestions((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, options: [...item.options, ''] } : item))}>添加选项</button></div> : <textarea placeholder="填写开放题作答提示，例如请详细说明原因或建议。" />}</article>)}<button className="secondary" onClick={() => setQuestions((current) => [...current, { type: '单选题', title: '', options: ['选项 1', '选项 2'] }])}>添加问题</button></div>}</section>
              </main>
            </div>
          </div>
        </div>
        <footer className="research-modal-footer"><button className="secondary" onClick={props.onClose}>取消</button><button className="primary" onClick={props.runSimulation}>{props.running ? '提交中' : '确定'}</button></footer>
      </section>
    </div>
  );
}

function ReportDetailModal({ task, reportTab, setReportTab, selectedTagObjects, sampleSize, onClose }) {
  const taskScenario = scenarios.find((item) => item.id === task.scenarioId);
  const reportDimensions = task.analysisDimensions || analysisDimensionOptions.slice(0, 4);
  const tabs = [['overview', '概览'], ['segments', '调研结果'], ['drivers', '归因路径']];
  const [calibrationOpen, setCalibrationOpen] = useState(false);

  return (
    <>
      <div className="modal-backdrop">
        <section className="report-detail">
          <header className="research-report-header">
            <div className="report-study-title">
              <strong>车型X 外观造型验证研究（定量调研）</strong>
              <span>报告编号：R-20240518-001　 样本量：1,206　 研究时间：2024.05.10 – 2024.05.16</span>
            </div>
            <nav className="research-report-tabs">{tabs.map(([id, label]) => <button className={reportTab === id ? 'active' : ''} onClick={() => setReportTab(id)} key={id}>{label}</button>)}</nav>
            <button type="button" className="report-calibration-entry" onClick={(event) => { event.preventDefault(); event.stopPropagation(); setCalibrationOpen(true); }}><SlidersHorizontal size={16} /> 校准优化</button>
            <button type="button" className="report-export"><Download size={16} /> 导出报告</button>
            <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
          </header>
          <ReportPanel
              scenario={taskScenario}
              reportTab={reportTab}
              setReportTab={setReportTab}
              running={false}
              selectedTagObjects={selectedTagObjects}
              sampleSize={sampleSize}
              analysisDimensions={reportDimensions}
              detailMode
          />
        </section>
      </div>
      {calibrationOpen && <CalibrationOptimizationModal task={task} onClose={() => setCalibrationOpen(false)} />}
    </>
  );
}

function CalibrationOptimizationModal({ task, onClose }) {
  const [evidenceItems, setEvidenceItems] = useState([]);
  const [uploadName, setUploadName] = useState('');
  const [uploadError, setUploadError] = useState('');
  const [sourceFilter, setSourceFilter] = useState('全部来源');
  const [selectedEvidence, setSelectedEvidence] = useState([]);
  const [instruction, setInstruction] = useState('');
  const [guardrail, setGuardrail] = useState('');
  const [candidateReady, setCandidateReady] = useState(false);
  const [draftSaved, setDraftSaved] = useState(false);

  function normalizeRows(rows) {
    return rows.map((row, index) => {
      const keys = Object.keys(row);
      const pick = (...names) => names.map((name) => row[name]).find(Boolean) || '';
      const quote = pick('反馈内容', '原文', 'content', 'comment', 'text', 'quote') || keys.map((key) => row[key]).find(Boolean) || '';
      return { id: `uploaded-${index}`, quote, source: pick('来源', 'source') || '上传数据', issue: pick('问题', '维度', 'issue', 'topic') || '待识别', profile: pick('样本画像', '人群', 'profile', 'segment') || task.consumer };
    }).filter((row) => row.quote);
  }

  async function readEvidenceFile(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploadError('');
    try {
      const text = await file.text();
      const rows = file.name.toLowerCase().endsWith('.json')
        ? JSON.parse(text)
        : (() => {
            const [headerLine, ...dataLines] = text.trim().split(/\r?\n/).filter(Boolean);
            const headers = headerLine.split(',').map((item) => item.trim());
            return dataLines.map((line) => Object.fromEntries(headers.map((header, index) => [header, line.split(',')[index]?.trim() || ''])));
          })();
      const normalized = normalizeRows(Array.isArray(rows) ? rows : []);
      if (!normalized.length) throw new Error('未读取到可用反馈内容');
      setEvidenceItems(normalized);
      setUploadName(file.name);
      setSelectedEvidence([]);
      setCandidateReady(false);
      setDraftSaved(false);
    } catch {
      setEvidenceItems([]);
      setUploadName('');
      setUploadError('读取失败：请上传 JSON 数组，或首行包含“反馈内容”的 CSV 文件。');
    }
  }

  function useEvidence(item) {
    setSelectedEvidence((current) => current.includes(item.id) ? current.filter((id) => id !== item.id) : [...current, item.id]);
    if (!selectedEvidence.includes(item.id)) setInstruction((current) => current.includes(item.issue) ? current : `${current}${current ? ' ' : ''}纳入“${item.issue}”的真实反馈证据。`);
  }

  const selectedCount = selectedEvidence.length;
  const sources = ['全部来源', ...Array.from(new Set(evidenceItems.map((item) => item.source)))];
  const visibleEvidence = sourceFilter === '全部来源' ? evidenceItems : evidenceItems.filter((item) => item.source === sourceFilter);
  return (
    <div className="calibration-modal-backdrop">
      <section className="calibration-modal" aria-label="校准优化">
        <header className="calibration-modal-head"><div><strong>校准优化</strong><span>{task.name} · 仅作用于当前调研任务</span></div><button className="icon-button" onClick={onClose} aria-label="关闭校准优化"><X size={18} /></button></header>
        <div className="calibration-workspace">
          {uploadError && <p className="calibration-upload-error">{uploadError}</p>}
          <div className="calibration-main-grid">
        <section className="calibration-evidence-panel">
          <header><div><strong>真实反馈结果</strong><span>{uploadName ? `${uploadName} · 已读取 ${evidenceItems.length} 条` : '请先上传当前任务的真实反馈数据'}</span></div>{evidenceItems.length > 0 && <select aria-label="筛选证据来源" value={sourceFilter} onChange={(event) => setSourceFilter(event.target.value)}>{sources.map((source) => <option key={source}>{source}</option>)}</select>}</header>
          {!evidenceItems.length ? <div className="calibration-evidence-empty"><Upload size={24} /><strong>上传后展示真实反馈结果</strong><span>支持 JSON 或 CSV；建议包含：反馈内容、来源、问题、样本画像。</span><label className="primary"><Upload size={15} />上传反馈数据<input type="file" accept=".csv,.json,.txt" onChange={readEvidenceFile} /></label></div> : <div className="calibration-evidence-list">
            {visibleEvidence.map((item) => <article className={selectedEvidence.includes(item.id) ? 'selected' : ''} key={item.id}>
              <p>“{item.quote}”</p><button type="button" className="secondary small" onClick={() => useEvidence(item)}>{selectedEvidence.includes(item.id) ? '已纳入指令' : '转为校准指令'}</button>
              <small>来源：{item.source}　 问题：{item.issue}</small><em>样本画像：{item.profile}</em>
            </article>)}</div>}
        </section>
        <section className="calibration-instruction-panel">
          <header><div><strong>校准指令</strong><span>让洞察更贴近真实消费者认知</span></div><b>{selectedCount} 条证据已引用</b></header>
          <label><span>期望调整 <em>*</em></span><textarea value={instruction} maxLength="200" placeholder="选择真实反馈后，填写希望校准的洞察判断…" onChange={(event) => setInstruction(event.target.value)} /><small>{instruction.length}/200</small></label>
          <label><span>当前任务消费者</span><div className="calibration-chip-input readonly"><i>{task.consumer}</i><b>任务样本 {formatNumber(task.sample || 0)} 人</b></div><small>从当前调研任务继承，不支持在校准时另行圈选。</small></label>
          <label><span>约束条件 <em>（可选）</em></span><textarea value={guardrail} maxLength="200" onChange={(event) => setGuardrail(event.target.value)} /><small>{guardrail.length}/200</small></label>
          <section className="calibration-scope"><strong>校准依据与影响范围</strong><div><span>依据数据</span><p>{selectedCount ? `已引用当前任务上传的 ${selectedCount} 条真实反馈，并结合你填写的期望调整${guardrail ? '与约束条件' : ''}。` : '请先上传并引用真实反馈；系统不会基于预置示例生成修改建议。'}</p></div><div><span>影响对象</span><p>仅重新计算当前任务「{task.consumer}」的报告洞察、归因结论与问答生成口径。</p></div><div><span>不影响</span><p>不会修改用户数据、标签体系、消费者模板或其他调研任务。</p></div></section>
          <label><span>指令备注 <em>（可选）</em></span><input placeholder="选填，补充说明该指令的背景或适用场景…" /></label>
          <div className="calibration-actions"><button className="secondary" disabled={!instruction && !selectedCount} onClick={() => setDraftSaved(true)}>{draftSaved ? '草稿已保存' : '保存草稿'}</button><button className="primary calibration-generate" disabled={!instruction || !selectedCount} onClick={() => setCandidateReady(true)}>{candidateReady ? '已生成待验证校准版本' : '生成并验证校准版本'}</button></div>
          {candidateReady && <p className="calibration-success"><Check size={15} />已生成当前任务的待验证校准版本；发布前将按上述真实反馈与约束进行校验。</p>}
        </section>
          </div>
        </div>
      </section>
    </div>
  );
}

function Stepper({ activeStep, setActiveStep }) {
  const steps = ['选择消费者', '选择调研场景', '调研任务设置'];
  return (
    <div className="stepper">
      {steps.map((step, index) => {
        const stepNumber = index + 1;
        return (
          <button
            className={stepNumber <= activeStep ? 'complete' : ''}
            onClick={() => setActiveStep(stepNumber)}
            key={step}
          >
            <span>{stepNumber < activeStep ? <Check size={14} /> : stepNumber}</span>
            {step}
          </button>
        );
      })}
    </div>
  );
}

function ConsumerPicker({ consumerTemplates: templates, selectedConsumerTemplateIds, setSelectedConsumerTemplateIds }) {
  function toggle(templateId) { setSelectedConsumerTemplateIds((current) => current.includes(templateId) ? current.filter((id) => id !== templateId) : [...current, templateId]); }
  return <section className="step-section"><div className="section-heading"><div><h2>选择消费者</h2><p>从当前消费者库选择一个或多个模板，调研将分别覆盖每个选定人群。</p></div></div><div className="consumer-template-strip">{templates.map((template) => <button className={selectedConsumerTemplateIds.includes(template.id) ? 'selected' : ''} onClick={() => toggle(template.id)} key={template.id}><strong>{template.name}</strong><span>{formatNumber(template.users)} 人 · {template.coverage}</span><small>{selectedConsumerTemplateIds.includes(template.id) ? '已选择' : '点击选择'}</small></button>)}</div></section>;
}

function TaskSettings(props) {
  const chosen = props.consumerTemplates.filter((template) => props.selectedConsumerTemplateIds.includes(template.id));
  return <div className="step-stack"><section className="task-settings"><div className="section-heading"><div><h2>调研任务设置</h2><p>补充任务名称、调研输入和样本配置后直接提交。</p></div></div><label>任务名称<input value={props.taskName} onChange={(event) => props.setTaskName(event.target.value)} /></label><InputPanel scenario={props.scenario} /><AudienceBuilder {...props} /></section><div className="review-strip"><div><strong>已选消费者：{chosen.map((item) => item.name).join('、') || '请选择消费者'}</strong><p>场景：{props.scenario.name}。提交后立即创建调研任务。</p></div></div></div>;
}

function ScenarioPicker({ activeScenario, setActiveScenario, scenarioTemplates: templates = scenarioTemplates, onManageScenarios }) {
  return (
    <section className="step-section">
      <div className="section-heading">
        <div>
          <h2>选择调研场景模板</h2>
          <p>场景模板由“调研场景”模块维护，决定输入结构、问题模板和报告口径。</p>
        </div>
        <button className="text-button" onClick={onManageScenarios}>管理场景模板 <ChevronRight size={15} /></button>
      </div>
      <div className="scenario-grid">
        {templates.map((template) => {
          const item = scenarios.find((scenario) => scenario.id === template.scenarioId);
          const Icon = item.icon;
          return (
            <button
              className={`scenario-card ${activeScenario === template.scenarioId ? 'selected' : ''}`}
              onClick={() => setActiveScenario(template.scenarioId)}
              key={template.id}
            >
              <span className="scenario-icon"><Icon size={20} /></span>
              <strong>{template.name}</strong>
              <small>{template.id} · {template.stage}</small>
              <p>{item.summary}</p>
            </button>
          );
        })}
      </div>
    </section>
  );
}

function InputPanel({ scenario }) {
  return (
    <section className="split-block">
      <div>
        <h2>{scenario.inputTitle}</h2>
        <p>当前内容会作为 AI 消费者调研输入，系统会保留结构化字段以支持后续归因。</p>
      </div>
      <textarea defaultValue={scenario.inputValue} aria-label={scenario.inputTitle} />
    </section>
  );
}

function AudienceStep(props) {
  function applyConsumerTemplate(template) {
    const matchedIds = props.tagGroups
      .flatMap((group) => group.tags)
      .filter((tag) => template.linkedTags.includes(tag.name))
      .map((tag) => tag.id);
    props.setActiveConsumerTemplate(template.id);
    if (matchedIds.length > 0) {
      props.setSelectedTags(matchedIds);
    }
  }

  return (
    <div className="step-stack">
      <InputPanel scenario={props.scenario} />
      <section>
        <div className="section-heading">
          <div>
            <h2>选择消费者模板</h2>
            <p>消费者模板由“标签体系 + 用户数据”生成，创建调研时优先调用模板，再按需微调标签。</p>
          </div>
        </div>
        <div className="consumer-template-strip">
          {props.consumerTemplates.map((template) => (
            <button className={props.activeConsumerTemplate === template.id ? 'selected' : ''} onClick={() => applyConsumerTemplate(template)} key={template.id}>
              <strong>{template.name}</strong>
              <span>{formatNumber(template.users)} 人 · {template.coverage}</span>
            </button>
          ))}
        </div>
      </section>
      <AudienceBuilder {...props} />
    </div>
  );
}

function AudienceBuilder({
  selectedTags,
  toggleTag,
  selectedTagObjects,
  estimatedPool,
  sampleSize,
  setSampleSize,
  confidence,
  setConfidence,
  sampleHealth,
  setSelectedTags,
  tagGroups: groups = tagGroups
}) {
  return (
    <section>
      <div className="section-heading">
        <div>
          <h2>定义目标受众</h2>
          <p>使用标签库圈选 AI 消费者池，实时预估样本量与人群画像。</p>
        </div>
        <button className="text-button" onClick={() => setSelectedTags([])}>清空条件</button>
      </div>
      <div className="audience-layout">
        <div className="tag-browser">
          {groups.map((group) => (
            <div className="tag-group" key={group.group}>
              <div className="tag-group-title">
                <span>{group.group}</span>
                <small>{group.tags.length} 项</small>
              </div>
              {group.tags.map((tag) => (
                <button className={selectedTags.includes(tag.id) ? 'tag-row selected' : 'tag-row'} onClick={() => toggleTag(tag.id)} key={tag.id}>
                  <span>
                    <Check size={13} />
                    {tag.name}
                  </span>
                  <small>{formatNumber(tag.size)}</small>
                </button>
              ))}
            </div>
          ))}
        </div>
        <div className="audience-summary">
          <div className="summary-header">
            <strong>已选标签</strong>
            <span>{selectedTagObjects.length}/8</span>
          </div>
          <div className="chips">
            {selectedTagObjects.map((tag) => (
              <button onClick={() => toggleTag(tag.id)} key={tag.id}>{tag.name} ×</button>
            ))}
          </div>
          <div className="sample-card">
            <div>
              <span>估计有效样本量</span>
              <strong>{formatNumber(sampleSize)}</strong>
              <em className={sampleHealth.tone}>{sampleHealth.label}</em>
            </div>
            <Gauge size={34} />
          </div>
          <div className="range-control">
            <label>
              样本规模 <strong>{sampleSize}</strong>
            </label>
            <input type="range" min="300" max="3000" value={sampleSize} onChange={(event) => setSampleSize(Number(event.target.value))} />
          </div>
          <div className="range-control">
            <label>
              置信水平 <strong>{confidence}%</strong>
            </label>
            <input type="range" min="80" max="98" value={confidence} onChange={(event) => setConfidence(Number(event.target.value))} />
          </div>
          <div className="pool-note">
            <Target size={16} />
            候选池约 {formatNumber(estimatedPool)} 人，发布前将按标签交集去重与配额抽样。
          </div>
        </div>
      </div>
    </section>
  );
}

function ResearchStep({ scenario }) {
  return (
    <div className="step-stack">
      <ResearchDesign scenario={scenario} />
      <div className="review-strip">
        <div>
          <strong>本步骤自检</strong>
          <p>问题模板、主问题和追加问题会影响 AI 消费者作答质量；发布前建议确保问题没有诱导性表述。</p>
        </div>
        <button className="secondary small">检查问卷逻辑</button>
      </div>
    </div>
  );
}

function ResearchDesign({ scenario }) {
  const [selectedTemplate, setSelectedTemplate] = useState(0);
  const [expanded, setExpanded] = useState(false);

  return (
    <section>
      <div className="section-heading">
        <div>
          <h2>研究设计</h2>
          <p>模板可作为基础问卷，支持追加场景特定问题与分群分析维度。</p>
        </div>
        <button className="secondary small" onClick={() => setExpanded((value) => !value)}>
          <Plus size={15} />
          添加问题
        </button>
      </div>
      <div className="question-layout">
        <div className="template-list">
          {questionTemplates.map((template, index) => (
            <button className={selectedTemplate === index ? 'selected' : ''} onClick={() => setSelectedTemplate(index)} key={template}>
              <span>{index + 1}</span>
              {template}
            </button>
          ))}
        </div>
        <div className="question-preview">
          <div className="preview-top">
            <strong>主问题</strong>
            <span>{scenario.name}</span>
          </div>
          <textarea defaultValue={scenario.defaultQuestion} aria-label="主问题" />
          {expanded && (
            <input className="custom-question" placeholder="输入追加问题，例如：按城市级别拆分最担心点" autoFocus />
          )}
        </div>
      </div>
    </section>
  );
}

function LaunchStep({ scenario, selectedTagObjects, activeConsumerTemplate, sampleSize, confidence, runSimulation, running, consumerTemplates: templates = consumerTemplates, scenarioTemplates: scenarioList = scenarioTemplates }) {
  const consumerTemplate = templates.find((template) => template.id === activeConsumerTemplate) || templates[0];
  const scenarioTemplate = scenarioList.find((template) => template.scenarioId === scenario.id) || scenarioList[0];

  return (
    <section className="launch-review">
      <div className="section-heading">
        <div>
          <h2>确认并启动</h2>
          <p>发布前检查研究场景、输入内容、人群范围和报告输出口径。</p>
        </div>
      </div>
      <div className="launch-grid">
        <div className="launch-item">
          <span>研究场景</span>
          <strong>{scenario.name}</strong>
          <p>{scenario.summary}</p>
        </div>
        <div className="launch-item">
          <span>消费者模板</span>
          <strong>{consumerTemplate.name} · {sampleSize.toLocaleString('zh-CN')} 份样本</strong>
          <p>{consumerTemplate.linkedTags.join(' / ')}；已叠加 {selectedTagObjects.length} 个标签条件。</p>
        </div>
        <div className="launch-item">
          <span>报告口径</span>
          <strong>关键结果 / 细分洞察 / 原因分析 / 建议</strong>
          <p>置信水平 {confidence}%，系统将按标签交集去重与配额抽样。</p>
        </div>
      </div>
      <div className="launch-checklist">
        <div>
          <Check size={15} />
          <span>消费者模板来自消费者库：{consumerTemplate.name}</span>
        </div>
        <div>
          <Check size={15} />
          <span>上游标签已同步：{selectedTagObjects.map((tag) => tag.name).join('、')}</span>
        </div>
        <div>
          <Check size={15} />
          <span>调研场景模板来自调研场景：{scenarioTemplate.name}</span>
        </div>
      </div>
      <div className="launch-action">
        <button className="primary" onClick={runSimulation}>
          {running ? <RefreshCw className="spin" size={16} /> : <Play size={16} />}
          {running ? 'AI消费者作答中' : '启动研究并生成报告'}
        </button>
      </div>
    </section>
  );
}

function ReportPanel({ scenario, reportTab, setReportTab, running, selectedTagObjects, sampleSize, analysisDimensions = analysisDimensionOptions.slice(0, 4) }) {
  return (
    <aside className={`report-panel ${reportTab === 'drivers' ? 'driver-report-panel' : ''}`}>
      {running ? (
        <div className="simulation-state">
          <RefreshCw className="spin" size={24} />
          <strong>AI消费者正在独立作答</strong>
          <p>已完成样本配额、标签去重、问题分发，正在聚合原声与归因。</p>
        </div>
      ) : (
        <>
          {reportTab === 'overview' && <OverviewReport scenario={scenario} sampleSize={sampleSize} analysisDimensions={analysisDimensions} />}
          {reportTab === 'segments' && <SegmentReport selectedTagObjects={selectedTagObjects} analysisDimensions={analysisDimensions} />}
          {reportTab === 'drivers' && <DriverReport analysisDimensions={analysisDimensions} />}
        </>
      )}
    </aside>
  );
}

function OverviewReport({ scenario, sampleSize, analysisDimensions }) {
  const distribution = [{ name: '非常喜欢（5分）', value: 22, color: '#1769e8' }, { name: '比较喜欢（4分）', value: 54, color: '#70a8f8' }, { name: '一般（3分）', value: 12, color: '#e1e6ee' }, { name: '不太喜欢（2分）', value: 8, color: '#fa9da3' }, { name: '非常不喜欢（1分）', value: 4, color: '#f12e2e' }];
  const population = [{ name: '总体', tested: 76, benchmark: 64, industry: 56 }, { name: '男性', tested: 78, benchmark: 62, industry: 53 }, { name: '女性', tested: 74, benchmark: 60, industry: 52 }, { name: '18-25岁', tested: 72, benchmark: 57, industry: 48 }, { name: '26-35岁', tested: 79, benchmark: 67, industry: 59 }, { name: '36-45岁', tested: 75, benchmark: 59, industry: 50 }, { name: '一线城市', tested: 80, benchmark: 69, industry: 61 }, { name: '新一线城市', tested: 77, benchmark: 65, industry: 57 }, { name: '二线城市', tested: 73, benchmark: 60, industry: 52 }, { name: '三线及以下', tested: 68, benchmark: 55, industry: 48 }];
  const radar = [{ subject: '动感 72%', value: 72, benchmark: 63 }, { subject: '独特性 68%', value: 68, benchmark: 60 }, { subject: '精致感 70%', value: 70, benchmark: 62 }, { subject: '高级感 65%', value: 65, benchmark: 58 }, { subject: '力量感 69%', value: 69, benchmark: 61 }, { subject: '协调性 75%', value: 75, benchmark: 66 }];
  const kpis = [{ label: '总体喜爱度', value: '76%', delta: '+7pp' }, { label: '独特性', value: '68%', delta: '+10pp' }, { label: '动感', value: '72%', delta: '+8pp' }, { label: '精致感', value: '70%', delta: '+6pp' }, { label: '高级感', value: '65%', delta: '+5pp' }, { label: '购买意向', value: '61%', delta: '+7pp' }];
  const voices = [['整体造型', '整体比例很协调，看起来很舒服，符合我的审美。', '正向', '18%'], ['前脸设计', '前脸很有辨识度，大灯造型很犀利，喜欢这种感觉。', '正向', '16%'], ['侧面线条', '侧面的腰线很流畅，显得车身修长有动感。', '正向', '14%'], ['尾部设计', '尾灯造型一般，感觉不够精致，希望能再优化。', '负向', '9%'], ['细节质感', '细节处理还可以再提升，比如轮毂设计有点普通。', '中性', '8%']];
  return (
    <div className="reference-report-dashboard">
      <section className="overview-actions"><div><Target/><p><strong>建议延续</strong><span>保留贯穿式灯带、运动前脸和低趴姿态，强化已形成的造型识别资产。</span></p></div><div><Settings/><p><strong>重点优化</strong><span>提升尾灯与后保险杠的精致度，降低尾部视觉厚重感。</span></p></div><div><TrendingUp/><p><strong>验证动作</strong><span>量产冻结前补充尾部 A/B 方案与 18–35 岁核心客群复测。</span></p></div></section>
      <section className="reference-panel overall-panel"><h3>总体评价 <span>(Overall Favorability)</span></h3><div className="overall-content"><div className="favorability-ring"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={[{ value: 76 }, { value: 24 }]} dataKey="value" startAngle={90} endAngle={-270} innerRadius="78%" outerRadius="92%" stroke="none"><Cell fill="#1769e8"/><Cell fill="#eef1f6"/></Pie></PieChart></ResponsiveContainer><div><strong>76%</strong><span>总体喜爱度</span></div></div><div className="overall-copy"><strong>结论：整体造型获得较高认可，符合目标人群审美偏好。</strong><p>76%的受访者对车型X的外观造型表示喜欢（Top2 Box），其中“非常喜欢”占比22%，“比较喜欢”占比54%。<br/>负向评价（不喜欢）占比12%，中立占比12%。</p></div></div></section>
      <section className="reference-panel kpi-panel"><h3>关键指标（与基准车型对比）</h3><div className="reference-kpis">{kpis.map((item)=><div key={item.label}><span>{item.label}</span><strong>{item.value}</strong><em>vs 基准　<b>{item.delta} ▲</b></em></div>)}</div></section>
      <section className="reference-panel distribution-panel"><div className="reference-panel-head"><h3>总体喜爱度分布</h3><strong>Top2 Box（喜欢）76%</strong></div><div className="stacked-distribution">{distribution.map(item=><div style={{width:`${item.value}%`,background:item.color}} key={item.name}>{item.value}%</div>)}</div><div className="distribution-legend">{distribution.map(item=><span key={item.name}><i style={{background:item.color}}/>{item.name}</span>)}</div></section>
      <section className="reference-panel population-panel"><div className="reference-panel-head"><h3>人群对比 <span>（与体喜爱度 Top2 Box %）</span></h3><div className="dimension-toggle"><button className="active">按人群维度</button><button>按年龄段</button></div></div><ResponsiveContainer width="100%" height="82%"><ComposedChart data={population} margin={{top:18,right:10,left:-18,bottom:0}}><CartesianGrid stroke="#e8edf4" vertical={false}/><XAxis dataKey="name" tick={{fontSize:10}}/><YAxis domain={[0,100]} tickFormatter={v=>`${v}%`} tick={{fontSize:10}}/><Tooltip/><Bar dataKey="tested" fill="#1769e8" barSize={18}/><Line dataKey="tested" stroke="#1769e8" strokeWidth={2}><LabelList dataKey="tested" position="top" formatter={(value) => `${value}%`} fill="#1769e8" fontSize={9}/></Line><Line dataKey="benchmark" stroke="#64748b" strokeWidth={1.5}/><Line dataKey="industry" stroke="#9bc5fa" strokeWidth={1.5}/></ComposedChart></ResponsiveContainer></section>
      <section className="reference-panel radar-panel"><h3>造型维度评价 <span>（Top2 Box %）</span></h3><ResponsiveContainer width="100%" height="88%"><RadarChart data={radar} outerRadius="72%"><PolarGrid/><PolarAngleAxis dataKey="subject" tick={{fontSize:10}}/><Radar dataKey="benchmark" stroke="#8da0b8" strokeDasharray="4 3" fill="transparent"/><Radar dataKey="value" stroke="#1769e8" strokeWidth={2} fill="#1769e8" fillOpacity={.08}/></RadarChart></ResponsiveContainer></section>
      <section className="reference-panel voice-panel"><h3>消费者原声（节选）</h3><div className="voice-table"><div className="voice-row head"><span>评价方向</span><span>原声评论</span><span>情感倾向</span><span>占比</span></div>{voices.map(row=><div className="voice-row" key={row[0]}>{row.map((cell,index)=><span className={index===2?(cell==='负向'?'negative':cell==='正向'?'positive':'neutral'):''} key={index}>{cell}</span>)}</div>)}</div></section>
      <footer>注：基准车型为竞品A，行业均值来自本平台同级别车型研究数据库（2023–2024）</footer>
    </div>
  );
}

function SegmentReport({ selectedTagObjects, analysisDimensions }) {
  const [page, setPage] = useState(1);
  const pageSize = 10;
  const users = Array.from({ length: 50 }, (_, index) => {
    const names = ['周雨晴', '陈昊', '赵一诺', '林悦', '王梓轩', '孙可欣', '张明远', '李思琪', '郭子涵', '吴嘉禾', '蒋欣然', '何宇航', '唐婉宁', '徐嘉铭', '韩依琳', '郑凯文', '冯若曦', '谢承泽'];
    const ages = ['26–35岁', '36–45岁', '18–25岁', '46岁以上', '26–35岁'];
    const cities = [{ name: '上海', tier: '一线' }, { name: '杭州', tier: '新一线' }, { name: '广州', tier: '一线' }, { name: '成都', tier: '新一线' }, { name: '北京', tier: '一线' }, { name: '苏州', tier: '新一线' }, { name: '武汉', tier: '二线' }, { name: '宁波', tier: '二线' }, { name: '洛阳', tier: '三线及以下' }, { name: '绵阳', tier: '三线及以下' }];
    const conclusions = ['非常喜欢，愿意试驾', '比较喜欢，关注尾部细节', '比较喜欢，价格合适可购买', '一般，需要提升品牌信任'];
    const tagGroups = [['本科', '已婚有孩', '收入20–30万'], ['研究生', '单身', '收入30–50万'], ['本科', '新婚', '收入15–20万'], ['大专', '已婚', '收入10–15万']];
    const city = cities[index % cities.length];
    const score = [5, 4, 4, 3][index % 4];
    return { id: `U-${String(10431 + index).padStart(5, '0')}`, name: names[index % names.length], gender: index % 2 ? '男' : '女', age: ages[index % ages.length], city: city.name, cityTier: city.tier, tags: tagGroups[index % tagGroups.length], score, intention: ['高', '中高', '中高', '中'][index % 4], conclusion: conclusions[index % conclusions.length], survey: { testDriveIntent: score >= 4, smartCockpitFocus: index % 7 !== 0 && index % 7 !== 1, rangeSensitive: index % 3 !== 1, reliabilityFocus: index % 4 !== 0, stylingImprovement: index % 5 < 2 } };
  });
  const asPercent = (count) => Math.round((count / users.length) * 100);
  const ageData = ['18–25岁', '26–35岁', '36–45岁', '46岁以上'].map(name => ({ name, value: asPercent(users.filter(user => user.age === name).length) }));
  const cityData = ['一线', '新一线', '二线', '三线及以下'].map(name => ({ name, value: asPercent(users.filter(user => user.cityTier === name).length) }));
  const behaviorData = [
    ['到店试驾意向', asPercent(users.filter(user => user.survey.testDriveIntent).length)],
    ['智能座舱关注', asPercent(users.filter(user => user.survey.smartCockpitFocus).length)],
    ['续航敏感', asPercent(users.filter(user => user.survey.rangeSensitive).length)],
    ['品牌可靠性关注', asPercent(users.filter(user => user.survey.reliabilityFocus).length)],
    ['尾部造型改进诉求', asPercent(users.filter(user => user.survey.stylingImprovement).length)]
  ];
  const totalPages = Math.ceil(users.length / pageSize);
  const currentUsers = users.slice((page - 1) * pageSize, page * pageSize);
  return (
    <div className="persona-report-dashboard">
      <section className="persona-summary-panel"><div><strong>核心消费者画像</strong><h3>26–35岁 · 一线/新一线 · 新能源首购/增购人群</h3><p>重视造型辨识度与智能体验，对20–25万元价格带接受度较高；购买决策同时受到品牌可靠性和真实续航影响。</p></div><div className="persona-tags">{['科技审美', '城市通勤', '品质升级', '理性决策', '家庭兼顾'].map(tag=><span key={tag}>{tag}</span>)}</div></section>
      <section className="persona-metric-strip">{[['有效样本','1,206'],['核心客群占比','42%'],['平均喜爱度','4.08 / 5'],['高购买意愿','61%'],['答卷完成率','98.7%']].map(([label,value])=><div key={label}><span>{label}</span><strong>{value}</strong></div>)}</section>
      <section className="reference-panel persona-chart"><h3>年龄结构</h3><ResponsiveContainer width="100%" height="88%"><BarChart data={ageData} layout="vertical" margin={{top:8,right:26,left:5,bottom:0}}><CartesianGrid stroke="#edf1f6" horizontal={false}/><XAxis type="number" domain={[0,40]} tickFormatter={v=>`${v}%`} tick={{fontSize:9}}/><YAxis type="category" dataKey="name" width={58} tick={{fontSize:9}}/><Tooltip formatter={v=>`${v}%`}/><Bar dataKey="value" fill="#1769e8" radius={[0,3,3,0]} barSize={13}><LabelList dataKey="value" position="right" formatter={v=>`${v}%`} fill="#1769e8" fontSize={9}/></Bar></BarChart></ResponsiveContainer></section>
      <section className="reference-panel persona-chart"><h3>城市级别分布</h3><ResponsiveContainer width="100%" height="88%"><BarChart data={cityData} margin={{top:16,right:8,left:-22,bottom:0}}><CartesianGrid stroke="#edf1f6" vertical={false}/><XAxis dataKey="name" tick={{fontSize:9}}/><YAxis domain={[0,40]} tickFormatter={v=>`${v}%`} tick={{fontSize:9}}/><Tooltip formatter={v=>`${v}%`}/><Bar dataKey="value" fill="#70a8f8" radius={[3,3,0,0]} barSize={25}><LabelList dataKey="value" position="top" formatter={v=>`${v}%`} fill="#1769e8" fontSize={9}/></Bar></BarChart></ResponsiveContainer></section>
      <section className="reference-panel persona-traits"><h3>关键调研行为统计</h3><div>{behaviorData.map(([label,value])=><p key={label}><span>{label}</span><i><b style={{width:`${value}%`}}/></i><strong>{value}%</strong></p>)}</div></section>
      <section className="sample-user-panel"><div className="sample-user-head"><strong>抽样用户与调研作答</strong></div><div className="sample-user-table"><div className="sample-row head"><span>用户ID</span><span>姓名</span><span>基本信息</span><span>城市</span><span>用户标签（个人 / 家庭 / 经济）</span><span>喜爱度</span><span>购买意愿</span><span>调研作答结论</span></div>{currentUsers.map(user=><div className="sample-row" key={user.id}><span>{user.id}</span><strong>{user.name}</strong><span>{user.gender} · {user.age}</span><span>{user.city}</span><span className="user-tag-cell">{user.tags.map(tag=><i key={tag}>{tag}</i>)}</span><span className="score">{'★'.repeat(user.score)}{'☆'.repeat(5-user.score)}</span><span><em className={`intent ${user.intention==='高'?'high':''}`}>{user.intention}</em></span><span>{user.conclusion}</span></div>)}</div><div className="sample-pagination"><button disabled={page===1} onClick={()=>setPage(value=>value-1)}>上一页</button>{Array.from({length:totalPages},(_,index)=><button className={page===index+1?'active':''} onClick={()=>setPage(index+1)} key={index}>{index+1}</button>)}<button disabled={page===totalPages} onClick={()=>setPage(value=>value+1)}>下一页</button></div></section>
    </div>
  );
}

function DriverReport({ analysisDimensions }) {
  const driverData = [{name:'前脸辨识度',value:82,type:'正向驱动'}, {name:'整体动感',value:78,type:'正向驱动'}, {name:'智能科技感',value:71,type:'正向驱动'}, {name:'尾部精致感',value:-43,type:'负向阻碍'}, {name:'品牌信任',value:-36,type:'负向阻碍'}, {name:'价格溢价',value:-31,type:'负向阻碍'}];
  return (
    <div className="driver-report-dashboard">
      <section className="driver-executive"><div><strong>模型归因分析</strong><h3>优先保留前脸辨识度，同时修复尾部精致感</h3><p>这是由真实评价、统计关系和核心客群表现共同支持的判断。前脸带来的正向购买意愿为 <b>+15.4pp</b>；尾部短板抵消 <b>3.8pp</b>，当前方案的可实现净提升为 <b>+11.6pp</b>。</p></div><div><span>结论可信度</span><strong>高</strong><em>3 类证据一致 · n=1,206</em></div></section>
      <section className="reference-panel causal-path-panel"><div className="reference-panel-head"><h3>模型归因路径</h3><strong>净提升 +11.6pp</strong></div><div className="attribution-explainer"><article><div className="attribution-icon"><Activity size={16}/></div><span>1 · 观察证据</span><strong>前脸辨识度得分 8.2/10</strong><p>高于竞品 0.9 分；34% 的造型原声提到灯组和科技感。</p></article><i>说明</i><article><div className="attribution-icon"><Gauge size={16}/></div><span>2 · 感知机制</span><strong>强化科技感与高级感</strong><p>核心客群中，这两项感知与试驾意愿呈显著正相关。</p></article><i>传导</i><article><div className="attribution-icon"><TrendingUp size={16}/></div><span>3 · 行为结果</span><strong>试驾与购买意愿 +15.4pp</strong><p>模型估计：保留前脸识别资产可带来主要正向贡献。</p></article><i>校正</i><article className="attribution-risk"><div className="attribution-icon"><TriangleAlert size={16}/></div><span>4 · 风险校正</span><strong>尾部精致感不足 −3.8pp</strong><p>品质感折损会抵消部分优势，因此净效果为 +11.6pp。</p></article></div></section>
      <section className="reference-panel driver-ranking"><h3>关键驱动与阻碍强度</h3><div>{driverData.map(item=><p key={item.name}><span>{item.name}</span><i className={item.value<0?'negative':''}><b style={{width:`${Math.abs(item.value)}%`}}/></i><strong className={item.value<0?'negative':''}>{item.value>0?'+':''}{item.value}</strong></p>)}</div></section>
      <section className="reference-panel evidence-panel"><h3>证据三角验证</h3><div className="evidence-grid"><div><span>量化证据</span><strong>前脸评分 8.2</strong><p>高于竞品基准 0.9 分，与购买意愿显著正相关。</p></div><div><span>消费者原声</span><strong>“第一眼很有科技感”</strong><p>前脸与灯组相关正向原声占全部造型评论的 34%。</p></div><div><span>客群差异</span><strong>26–35岁效应最强</strong><p>核心客群路径系数 β 0.48，高于总体样本。</p></div><div><span>风险信号</span><strong>尾部负向 9%</strong><p>负向评价集中在灯组层次、厚重感和精致度。</p></div></div></section>
      <section className="reference-panel expert-actions"><div className="expert-actions-head"><div><h3>研究判断与下一步</h3><span>按决策优先级排序</span></div><strong>3 项行动建议</strong></div><div><article><div className="action-icon preserve"><Check size={16}/></div><p><em>优先级 P0 · 设计决策</em><strong>冻结高识别度核心造型</strong><span>保留灯带、低趴比例与运动前脸，避免量产阶段大幅调整核心设计语言。</span></p><b>立即执行</b></article><article><div className="action-icon optimize"><Settings size={16}/></div><p><em>优先级 P1 · 方案验证</em><strong>启动尾部精致感 A/B 测试</strong><span>针对尾灯内部结构、后保险杠层次与视觉重心形成两套优化方案。</span></p><b>2 周内</b></article><article><div className="action-icon validate"><Filter size={16}/></div><p><em>优先级 P1 · 客群验证</em><strong>补充核心客群分层研究</strong><span>追加 26–35 岁与家庭增购样本，验证品牌信任对购买转化的调节效应。</span></p><b>下轮研究</b></article></div></section>
      <footer>方法说明：多元回归、结构方程与消费者原声主题聚类交叉验证；显著性阈值 p &lt; 0.05。</footer>
    </div>
  );
}

function ActionReport({ scenario }) {
  return (
    <div className="report-stack">
      <div className="action-list">
        <div>
          <Check size={16} />
          <p>{scenario.recommendation}</p>
        </div>
        <div>
          <Filter size={16} />
          <p>建议按年龄、城市级别、家庭状态输出二级报告，确认是否存在传播分层。</p>
        </div>
        <div>
          <Clock3 size={16} />
          <p>下一轮可追加竞品刺激物测试，将本品优势转成上市话术。</p>
        </div>
      </div>
    </div>
  );
}

function QuoteList() {
  return (
    <div className="quote-list">
      <div className="chart-head">
        <strong>消费者原声</strong>
        <span>自动聚类</span>
      </div>
      {quotes.map((quote) => (
        <button className="quote-item" key={quote.text}>
          <MessagesSquare size={15} />
          <div>
            <p>“{quote.text}”</p>
            <span>{quote.persona} · {quote.sentiment}</span>
          </div>
        </button>
      ))}
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
